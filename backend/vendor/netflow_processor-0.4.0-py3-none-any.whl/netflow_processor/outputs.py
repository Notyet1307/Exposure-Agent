import hashlib
import json
import os
from pathlib import Path

from .contracts import PipelineError, validate_document


def write_json(path, value):
    with path.open('w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, allow_nan=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


class Writer:
    def __init__(self, directory, limit, *, include_peers=False):
        self.directory, self.limit, self.size = directory, limit, 0
        self.counts = {}
        self.files = {}
        names = ('observations.jsonl','candidates.jsonl','review.jsonl','invalid-records.jsonl')
        for name in names + (('peers.jsonl',) if include_peers else ()):
            self.files[name] = (directory/name).open('w', encoding='utf-8')
            self.counts[name] = 0

    def put(self, name, value, kind):
        self.put_many([(name, value, kind)])

    def put_many(self, items):
        encoded = []
        for name, value, kind in items:
            validate_document(value, kind)
            encoded.append((name, json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))+'\n'))
        size = sum(len(line.encode('utf-8')) for _, line in encoded)
        if self.size + size > self.limit:
            raise PipelineError('OUTPUT_BYTES_LIMIT', 4)
        for name, line in encoded:
            self.files[name].write(line)
            self.counts[name] += 1
        self.size += size

    def close(self):
        for f in self.files.values():
            if not f.closed:
                f.flush()
                os.fsync(f.fileno())
                f.close()

    def artifacts(self):
        out = []
        for name in self.files:
            p = self.directory/name
            h = hashlib.sha256()
            with p.open('rb') as f:
                for block in iter(lambda:f.read(1024*1024), b''):
                    h.update(block)
            out.append(dict(path=name, records=self.counts[name], bytes=p.stat().st_size, sha256=h.hexdigest()))
        return out
