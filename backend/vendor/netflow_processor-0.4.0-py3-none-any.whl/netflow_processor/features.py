from collections import Counter
from dataclasses import dataclass, field
import ipaddress

from .contracts import FEATURE_VERSION, PipelineError, digest

DOCUMENTATION = tuple(ipaddress.ip_network(n) for n in ('192.0.2.0/24', '198.51.100.0/24', '203.0.113.0/24', '2001:db8::/32'))
INTERNAL = tuple(ipaddress.ip_network(n) for n in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', 'fc00::/7', '169.254.0.0/16', 'fe80::/10', '127.0.0.0/8', '::1/128'))


def in_networks(ip, networks):
    return any(ip.version == n.version and ip in n for n in networks)


def public(ip, fixture):
    return (ip.is_global and not ip.is_multicast and not ip.is_reserved) or (fixture and in_networks(ip, DOCUMENTATION))


@dataclass
class Group:
    ip: str
    protocol: int
    port: int | None
    counts: Counter = field(default_factory=Counter)
    peers: set = field(default_factory=set)
    pairs: dict = field(default_factory=dict)
    refs: list = field(default_factory=list)
    first: str | None = None
    last: str | None = None
    flags_union: int = 0
    byte_sum: int = 0
    packet_sum: int = 0


class Aggregator:
    def __init__(self, context, config, networks):
        self.ctx, self.cfg, self.networks = context, config, networks
        self.groups, self.hosts = {}, {}
        self.peer_groups = {}
        self.source_only = context.endpoint_selection == 'declared_source'
        self.peer_entries = self.tuple_entries = 0
        self.without_managed = self.self_loops = 0

    def add(self, row):
        endpoints = [(row.src_ip, row.src_port, row.dst_ip, row.dst_port, 1),
                     (row.dst_ip, row.dst_port, row.src_ip, row.src_port, 2)]
        selfloop = row.src_ip == row.dst_ip
        if selfloop:
            self.self_loops += 1
            if not self.source_only:
                endpoints = [(row.src_ip, row.src_port if row.src_port == row.dst_port else None, row.dst_ip, row.dst_port, 3)]
        matched = self.source_only
        for addr, port, peer, remote_port, side in endpoints:
            address, peeraddr = ipaddress.ip_address(addr), ipaddress.ip_address(peer)
            managed = in_networks(address, self.networks)
            matched |= managed
            if not self.source_only and not managed and self.ctx.scope_confirmation == 'confirmed':
                continue
            # Unknown scope with hints retains only hinted endpoints. With no hints both ends are diagnostics.
            if not self.source_only and not managed and self.networks:
                continue
            peer_view = self.source_only and side == 2
            groups = self.peer_groups if peer_view else self.groups
            key = (addr, row.protocol, port)
            if key not in groups:
                if len(self.groups) + len(self.peer_groups) >= self.cfg.bounds['max_aggregate_groups']:
                    raise PipelineError('AGGREGATE_GROUP_LIMIT', 4)
                groups[key] = Group(*key)
            g = groups[key]
            if not peer_view:
                h = self.hosts.setdefault((addr, row.protocol), Counter())
                h[port] += 1
            c = g.counts
            c['record_count'] += 1
            c['source_count'] += bool(side & 1)
            c['destination_count'] += bool(side & 2)
            c['self_loop_count'] += selfloop
            if peer not in g.peers:
                if self.peer_entries >= self.cfg.bounds['max_peer_entries']:
                    raise PipelineError('PEER_ENTRIES_LIMIT', 4)
                g.peers.add(peer)
                self.peer_entries += 1
            internal = in_networks(peeraddr, self.networks) or in_networks(peeraddr, INTERNAL)
            external = not internal and public(peeraddr, self.ctx.test_fixture)
            if self.source_only:
                # This is a row-position declaration, never an IP-wide ownership rule.
                internal, external = peer_view, not peer_view
            c['internal_peer_records'] += internal
            c['external_peer_records'] += external
            c['unknown_peer_records'] += not internal and not external
            if not self.source_only and row.protocol in (6,17) and port is not None and remote_port is not None and not selfloop:
                pair = (peer, remote_port)
                if pair not in g.pairs:
                    if self.tuple_entries >= self.cfg.bounds['max_tuple_entries']:
                        raise PipelineError('TUPLE_ENTRIES_LIMIT', 4)
                    self.tuple_entries += 1
                g.pairs[pair] = g.pairs.get(pair, 0) | side
            if len(g.refs) < self.cfg.bounds['max_evidence_refs_per_item']:
                g.refs.append(row.source_ref)
            for value, counter, attr in ((row.in_bytes, 'bytes_known_records', 'byte_sum'), (row.in_packets, 'packets_known_records', 'packet_sum')):
                if value is not None:
                    c[counter] += 1
                    setattr(g, attr, getattr(g, attr) + value)
            c['start_missing_records'] += row.start_time is None
            c['end_missing_records'] += row.end_time is None
            if row.start_time:
                g.first = min(g.first, row.start_time) if g.first else row.start_time
            if row.end_time:
                g.last = max(g.last, row.end_time) if g.last else row.end_time
            if row.protocol == 6 and row.tcp_flags is not None:
                c['flags_known_records'] += 1
                g.flags_union |= row.tcp_flags
                syn = bool(row.tcp_flags & 2)
                ack = bool(row.tcp_flags & 16)
                for mask, prefix in ((1, 'source'), (2, 'destination')):
                    if side & mask:
                        c[prefix + '_syn_without_ack_records'] += syn and not ack
                        c[prefix + '_syn_ack_records'] += syn and ack
        if not matched:
            self.without_managed += 1

    def observations(self):
        crossover = self.address_crossover()
        host_summaries = {}
        for key, ports in self.hosts.items():
            total = sum(ports.values())
            distribution = sorted(ports.items(), key=lambda p: (-p[1], -1 if p[0] is None else p[0]))
            host_summaries[key] = (total, sum(p is not None for p in ports), max(ports.values())/total,
                                   [{'port':p,'records':n} for p,n in distribution[:8]], max(0,len(ports)-8))
        ordered = sorted(self.groups.values(), key=lambda g: (ipaddress.ip_address(g.ip).version, int(ipaddress.ip_address(g.ip)), g.protocol, -1 if g.port is None else g.port))
        for g in ordered:
            c = g.counts
            total, distinct, ratio, distribution, omitted = host_summaries[(g.ip,g.protocol)]
            fields = ('record_count','source_count','destination_count','self_loop_count','internal_peer_records','external_peer_records','unknown_peer_records','bytes_known_records','packets_known_records','start_missing_records','end_missing_records','flags_known_records','source_syn_without_ack_records','destination_syn_without_ack_records','source_syn_ack_records','destination_syn_ack_records')
            features = {k: c[k] for k in fields}
            features.update(feature_version=FEATURE_VERSION, peer_count=len(g.peers), peer_count_method='exact',
                            host_record_count=total, host_distinct_local_ports=distinct,
                            host_top_port_ratio=ratio, local_port_share=c['record_count']/total,
                            host_local_port_distribution=distribution, host_distribution_omitted_ports=omitted,
                            reverse_tuple_count=sum(bits == 3 for bits in g.pairs.values()),
                            directional_tuple_count=len(g.pairs),
                            bidirectional_method=('not_evaluated_source_column_only' if self.source_only else 'same_endpoint_protocol_local_port_peer_peer_port_opposite_sides_in_dataset_no_order_or_time_overlap_guarantee'),
                            bytes_sum_known=g.byte_sum if c['bytes_known_records'] else None,
                            packets_sum_known=g.packet_sum if c['packets_known_records'] else None,
                            start_time_utc=g.first, end_time_utc=g.last,
                            tcp_flags_union=g.flags_union if c['flags_known_records'] else None,
                            sampling=self.ctx.sampling,
                            missing=[name for name, missing in [('start_time', c['start_missing_records']), ('end_time',c['end_missing_records']), ('bytes',c['record_count']-c['bytes_known_records']), ('packets',c['record_count']-c['packets_known_records']), ('tcp_flags',c['record_count']-c['flags_known_records'] if g.protocol==6 else 0), ('local_port',g.port is None)] if missing])
            address = ipaddress.ip_address(g.ip)
            if self.source_only:
                features.update(source_column_only=True, address_side_crossover=g.ip in crossover)
            identity = [self.ctx.tenant_id, self.ctx.project_id, self.ctx.network_namespace, address.version, g.ip, g.protocol, g.port]
            yield dict(object_key='svc:' + digest(identity), ip=g.ip, ip_version=address.version, protocol=g.protocol,
                       local_port=g.port, scope_eligibility=('declared_source_position' if self.source_only else 'managed' if self.ctx.scope_confirmation=='confirmed' else self.ctx.scope_confirmation),
                       address_public_eligible=public(address, self.ctx.test_fixture), features=features,
                       source_refs=g.refs, source_refs_omitted=c['record_count']-len(g.refs))

    def address_crossover(self):
        return {g.ip for g in self.groups.values()} & {g.ip for g in self.peer_groups.values()}

    def peers(self):
        crossover = self.address_crossover()
        for key, g in sorted(self.peer_groups.items(), key=lambda item: (item[0][0], item[0][1], item[0][2] or 0)):
            yield dict(schema_version='netflow-peers-v1', peer_key='peer:' + digest([
                self.ctx.tenant_id, self.ctx.project_id, self.ctx.network_namespace, *key]),
                ip=g.ip, ip_version=ipaddress.ip_address(g.ip).version, protocol=g.protocol, peer_port=g.port,
                record_count=g.counts['record_count'], local_source_count=len(g.peers),
                start_time_utc=g.first, end_time_utc=g.last, source_refs=g.refs,
                source_refs_omitted=g.counts['record_count']-len(g.refs),
                address_side_crossover=g.ip in crossover, role_basis='declared_destination_position',
                is_local_candidate=False, external_reachability='NOT_VERIFIED', test_fixture=self.ctx.test_fixture)
