"""Strict streaming CSV. No exception text includes input values."""
import codecs
import csv
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
import hashlib
import ipaddress
import re
from zoneinfo import ZoneInfo

from .contracts import PipelineError

RAW = ['IP_SRC_ADDR', 'IP_DST_ADDR', 'PROTOCOL', 'L4_SRC_PORT', 'L4_DST_PORT',
       'start_time', 'end_time', 'IN_BYTES', 'IN_PKTS', 'TCP_FLAGS']
CANON = ['source_record_key', 'src_ip', 'dst_ip', 'protocol', 'src_port', 'dst_port',
         'start_time_utc', 'end_time_utc', 'in_bytes_estimated', 'in_packets_estimated', 'tcp_flags']
INTEGER = re.compile(r'(?:0|[1-9][0-9]*)\Z', re.ASCII)


@dataclass
class Record:
    source_ref: str
    src_ip: str
    dst_ip: str
    protocol: int
    src_port: int | None
    dst_port: int | None
    start_time: str | None
    end_time: str | None
    in_bytes: int | None
    in_packets: int | None
    tcp_flags: int | None
    mapped_count: int = 0

    def duplicate_payload(self):
        return {k: v for k, v in asdict(self).items() if k not in ('source_ref', 'mapped_count')}


def hash_file(path, limit):
    h, n = hashlib.sha256(), 0
    try:
        with path.open('rb') as f:
            for block in iter(lambda: f.read(1024 * 1024), b''):
                n += len(block)
                if n > limit:
                    raise PipelineError('INPUT_BYTES_LIMIT', 4)
                h.update(block)
    except FileNotFoundError:
        raise PipelineError('INPUT_NOT_FOUND') from None
    except OSError:
        raise PipelineError('INPUT_READ_ERROR') from None
    return h.hexdigest(), n


def select_encoding(path, encoding):
    if encoding != 'auto':
        return encoding
    for candidate in ('utf-8-sig', 'gb18030'):
        decoder = codecs.getincrementaldecoder(candidate)(errors='strict')
        try:
            with path.open('rb') as f:
                for block in iter(lambda: f.read(1024 * 1024), b''):
                    decoder.decode(block)
                decoder.decode(b'', final=True)
            return candidate
        except UnicodeDecodeError:
            continue
    raise PipelineError('INVALID_ENCODING_BYTES')


def ip(text):
    try:
        if '%' in text:
            raise ValueError()
        addr = ipaddress.ip_address(text)
        mapped = getattr(addr, 'ipv4_mapped', None)
        return str(mapped or addr), int(mapped is not None)
    except ValueError:
        raise PipelineError('INVALID_IP') from None


def number(text, maximum, code, minimum=0):
    if not text:
        return None
    if not INTEGER.fullmatch(text) or len(text) > 20 or not minimum <= int(text) <= maximum:
        raise PipelineError(code)
    return int(text)


def timestamp(text, ctx, profile):
    if not text:
        return None
    try:
        if profile == 'exposure':
            if not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ', text, re.ASCII):
                raise ValueError()
            dt = datetime.strptime(text, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
        elif profile == 'exposure-raw-v1':
            dt = datetime.strptime(text, '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone(timedelta(hours=8)))
        else:
            if not re.fullmatch(r'\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d(?:Z|[+-]\d\d:\d\d)?', text, re.ASCII):
                raise ValueError()
            dt = datetime.fromisoformat(text.replace('Z', '+00:00'))
            if dt.tzinfo is None:
                zone = timezone(timedelta(hours=8)) if ctx.input_timezone == '+08:00' else ZoneInfo(ctx.input_timezone)
                a, b = dt.replace(tzinfo=zone, fold=0), dt.replace(tzinfo=zone, fold=1)
                if a.utcoffset() != b.utcoffset() or a.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None) != dt:
                    raise ValueError()
                dt = a
        return dt.astimezone(timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')
    except (ValueError, OverflowError):
        raise PipelineError('INVALID_TIME') from None


def normalize(row, index, ctx, cfg):
    canonical = cfg.input_profile == 'exposure'
    compatibility = cfg.input_profile == 'exposure-raw-v1'
    warnings = []
    values = [row.get(k, '') for k in (CANON[1:] if canonical else RAW)]
    a, b, proto, sport, dport, start, end, by, pk, flags = values
    a, ma = ip(a)
    b, mb = ip(b)
    proto = number(proto, 255, 'INVALID_PROTOCOL')
    if proto is None:
        raise PipelineError('MISSING_PROTOCOL')

    def optional(fn, value):
        try:
            return fn(value)
        except PipelineError as e:
            if not compatibility:
                raise
            warnings.append(e.code + '_NULL')
            return None

    if proto in (6, 17):
        port = lambda t: None if t in ('', '0') else number(t, 65535, 'INVALID_PORT', 1)
        sport, dport = optional(port, sport), optional(port, dport)
    else:
        if sport not in ('', '0') or dport not in ('', '0'):
            warnings.append('PORTS_NOT_APPLICABLE')
        sport = dport = None
    start, end = [optional(lambda t: timestamp(t, ctx, cfg.input_profile), v) for v in (start, end)]
    if start and end and end < start:
        if not compatibility:
            raise PipelineError('REVERSED_TIME')
        warnings.append('REVERSED_TIME_NULL')
        start = end = None
    by = optional(lambda t: number(t, 2**64-1, 'INVALID_BYTES'), by)
    pk = optional(lambda t: number(t, 2**64-1, 'INVALID_PACKETS'), pk)
    flags = optional(lambda t: number(t, 255, 'INVALID_FLAGS'), flags)
    if proto != 6 and flags is not None:
        warnings.append('FLAGS_NOT_TCP')
        flags = None
    ref = row['source_record_key'] if canonical else 'row:' + str(index)
    if not ref or len(ref) > 256 or any(ord(c) < 32 for c in ref):
        raise PipelineError('INVALID_SOURCE_REF')
    return Record(ref, a, b, proto, sport, dport, start, end, by, pk, flags, ma+mb), warnings


def rows(path, ctx, cfg, metadata):
    encoding = select_encoding(path, cfg.encoding)
    metadata['encoding'] = encoding
    try:
        with path.open(encoding=encoding, errors='strict', newline='') as f:
            reader = csv.reader(f, delimiter=cfg.delimiter, strict=True)
            header = next(reader, None)
            if not header:
                raise PipelineError('MISSING_HEADER')
            if len(header) > 64 or len(set(header)) != len(header):
                raise PipelineError('INVALID_HEADER')
            if any(len(x) > cfg.bounds['max_field_chars'] for x in header):
                raise PipelineError('FIELD_LIMIT', 4)
            if cfg.input_profile == 'exposure':
                if header != CANON:
                    raise PipelineError('CANONICAL_HEADER_MISMATCH')
            else:
                if set(cfg.field_mapping) - set(RAW) or len(set(cfg.field_mapping.values())) != len(cfg.field_mapping):
                    raise PipelineError('INVALID_FIELD_MAPPING')
                names = {name: cfg.field_mapping.get(name, name) for name in RAW}
                if len(set(names.values())) != len(names):
                    raise PipelineError('AMBIGUOUS_FIELD_MAPPING')
                if any(names[name] not in header for name in RAW[:5]):
                    raise PipelineError('MISSING_REQUIRED_COLUMNS')
            metadata['ignored_column_count'] = len(set(header) - (set(CANON) if cfg.input_profile == 'exposure' else set(names.values())))
            for index, values in enumerate(reader, 1):
                if index > cfg.bounds['max_records']:
                    raise PipelineError('RECORD_LIMIT', 4)
                if any(len(v) > cfg.bounds['max_field_chars'] for v in values):
                    raise PipelineError('FIELD_LIMIT', 4)
                try:
                    if len(values) != len(header):
                        raise PipelineError('COLUMN_COUNT_MISMATCH')
                    data = dict(zip(header, values))
                    if cfg.input_profile != 'exposure':
                        data = {name: data.get(mapped, '') for name, mapped in names.items()}
                    record, warnings = normalize(data, index, ctx, cfg)
                    yield index, record, warnings, None
                except PipelineError as e:
                    yield index, None, [], e.code
    except UnicodeDecodeError:
        raise PipelineError('INVALID_ENCODING_BYTES') from None
    except csv.Error:
        raise PipelineError('MALFORMED_CSV') from None
    except OSError:
        raise PipelineError('INPUT_READ_ERROR') from None
