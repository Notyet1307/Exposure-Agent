"""Structured declarations over immutable review tasks; no automatic task closure."""
from collections import Counter
from datetime import datetime
from importlib.resources import files
import hashlib
import ipaddress
from itertools import islice
import json
import os
from pathlib import Path
import re
import tempfile
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from jsonschema import Draft202012Validator, FormatChecker, ValidationError

from .contracts import VERSION, PipelineError, digest, validate_document
from .outputs import write_json
from .triage import TASKS, validate_review
from . import laya_adapter

FEEDBACK_VERSION = 'netflow-feedback-v1'
MAX_TASKS = 10_000
MAX_FEEDBACK_BYTES = 16 * 1024 * 1024
MAX_OUTPUT_BYTES = 64 * 1024 * 1024
MAX_SOURCE_BYTES = 256 * 1024 * 1024
MAX_LINE_BYTES = 65_536
MAX_PROGRESS_LINE_BYTES = 524_288
_SCHEMA = None
_VALIDATORS = {}


def feedback_schema():
    global _SCHEMA
    if _SCHEMA is None:
        _SCHEMA = json.loads(files('netflow_processor').joinpath('schemas/netflow-feedback-v1.json').read_text())
    return _SCHEMA


def _validator(kind):
    if kind not in _VALIDATORS:
        _VALIDATORS[kind] = Draft202012Validator(feedback_schema() | {'$ref':'#/$defs/'+kind}, format_checker=FormatChecker())
    return _VALIDATORS[kind]


def validate_feedback(value, kind):
    _validator(kind).validate(value)


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('DUPLICATE_JSON_KEY')
        result[key] = value
    return result


def _decode(raw):
    def reject(_):
        raise ValueError('NONFINITE_JSON')
    try:
        return json.loads(raw, object_pairs_hook=_pairs, parse_constant=reject)
    except (ValueError, RecursionError):
        raise PipelineError('INVALID_FEEDBACK_JSON') from None


def _fingerprint(path, limit):
    h = hashlib.sha256(); size = 0
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            size += len(block)
            if size > limit:
                raise PipelineError('FEEDBACK_SOURCE_LIMIT', 4)
            h.update(block)
    return {'sha256':h.hexdigest(), 'bytes':size}


def _read_json(path, limit, snapshots):
    path = Path(path)
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise PipelineError('FEEDBACK_SOURCE_LIMIT', 4)
    snapshots[path] = (hashlib.sha256(raw).hexdigest(), len(raw), limit)
    return _decode(raw)


def _bind_artifact(path, artifact, limit, snapshots):
    value = _fingerprint(path, limit)
    if any(value[k] != artifact[k] for k in ('sha256','bytes')):
        raise PipelineError('FEEDBACK_SOURCE_CHANGED')
    snapshots[Path(path)] = (value['sha256'], value['bytes'], limit)


def _unchanged(snapshots):
    for path, (sha, size, limit) in snapshots.items():
        value = _fingerprint(path, limit)
        if value != {'sha256':sha, 'bytes':size}:
            raise PipelineError('FEEDBACK_SOURCE_CHANGED')


def _lines(path, limit=MAX_LINE_BYTES):
    with Path(path).open('rb') as stream:
        while raw := stream.readline(limit + 1):
            if len(raw) > limit:
                raise PipelineError('FEEDBACK_ROW_LIMIT', 4)
            yield _decode(raw)


def _source(result_dir, review_dir):
    """Bind old v1 plans without changing their schema or historical files."""
    result_dir, review_dir = Path(result_dir), Path(review_dir)
    snapshots = {}
    m = _read_json(result_dir/'manifest.json', 1024*1024, snapshots)
    s = _read_json(review_dir/'summary.json', 1024*1024, snapshots)
    try:
        validate_document(m, 'manifest'); validate_review(s, 'summary')
    except ValidationError:
        raise PipelineError('INVALID_FEEDBACK_SOURCE') from None
    if m['status'] not in ('success','success_with_warnings') or not m['pipeline_complete']:
        raise PipelineError('FEEDBACK_REQUIRES_COMPLETE_RESULT')
    original = [a for a in m['artifacts'] if a['path']=='observations.jsonl']
    if len(original) != 1 or s['source_run_id'] != m['run_id'] or s['source_input_sha256'] != m['input_sha256'] or s['test_fixture'] != m['test_fixture'] or s['source_observations_sha256'] != original[0]['sha256']:
        raise PipelineError('FEEDBACK_SOURCE_BINDING_MISMATCH')
    if s['observations'] != original[0]['records'] or s['total_review_tasks'] != sum(s['task_counts'].values()):
        raise PipelineError('FEEDBACK_SOURCE_COUNT_MISMATCH')
    if s['total_review_tasks'] > MAX_TASKS:
        raise PipelineError('FEEDBACK_TASK_LIMIT', 4)
    limit = min(MAX_SOURCE_BYTES, m['limits']['max_output_bytes'])
    _bind_artifact(result_dir/'observations.jsonl', original[0], limit, snapshots)
    artifacts = {a['path']:a for a in s['artifacts']}
    if len(artifacts) != 2 or len(s['artifacts']) != 2 or set(artifacts) != {'review-tasks.jsonl','enriched-observations.jsonl'}:
        raise PipelineError('INVALID_FEEDBACK_SOURCE_ARTIFACTS')
    for name, artifact in artifacts.items():
        _bind_artifact(review_dir/name, artifact, limit, snapshots)
    identity = [m[k] for k in ('tenant_id','project_id','network_namespace','dataset_id')]
    tasks = {}
    for task in _lines(review_dir/'review-tasks.jsonl'):
        try:
            validate_review(task, 'task')
        except ValidationError:
            raise PipelineError('INVALID_FEEDBACK_TASK') from None
        kind, key = task['task_kind'], task['object_key']
        if kind not in TASKS or task['task_id'] in tasks or task['source_run_id'] != m['run_id'] or task['test_fixture'] != m['test_fixture']:
            raise PipelineError('INVALID_FEEDBACK_TASK')
        if task['task_id'] != 'task:'+digest(identity+[s['policy_version'],kind,key or 'batch']):
            raise PipelineError('FEEDBACK_TASK_ID_MISMATCH')
        if bool(key) != (kind=='service') or task['task_scope'] != ('object' if key else 'dataset') or (key is None and (task['target'] is not None or task['observation_window'] is not None)):
            raise PipelineError('FEEDBACK_TASK_TARGET_MISMATCH')
        tasks[task['task_id']] = task
        if len(tasks) > MAX_TASKS:
            raise PipelineError('FEEDBACK_TASK_LIMIT', 4)
    if len(tasks) != s['total_review_tasks'] or dict(Counter(t['task_kind'] for t in tasks.values())) != s['task_counts']:
        raise PipelineError('FEEDBACK_SOURCE_COUNT_MISMATCH')
    # The current policy only depends on independent scope/NAT/export tasks.
    for task in tasks.values():
        if len(task['depends_on']) != len(set(task['depends_on'])):
            raise PipelineError('INVALID_FEEDBACK_DEPENDENCIES')
        for dep in task['depends_on']:
            if dep not in tasks or tasks[dep]['task_kind'] not in ('scope','nat','export') or tasks[dep]['depends_on'] or dep==task['task_id']:
                raise PipelineError('INVALID_FEEDBACK_DEPENDENCIES')
    targets = {t['object_key']:t for t in tasks.values() if t['object_key']}
    seen = set(); count = 0
    for o in _lines(result_dir/'observations.jsonl'):
        try:
            validate_document(o, 'observation')
        except ValidationError:
            raise PipelineError('INVALID_FEEDBACK_SOURCE') from None
        if any(o[k] != m[k] for k in ('tenant_id','project_id','dataset_id','network_namespace','test_fixture')):
            raise PipelineError('FEEDBACK_SOURCE_BINDING_MISMATCH')
        count += 1
        if count > min(100_000, m['limits']['max_output_items']):
            raise PipelineError('FEEDBACK_SOURCE_LIMIT', 4)
        if o['object_key'] in targets:
            t = targets[o['object_key']]
            window = {'start_time_utc':o['features']['start_time_utc'],'end_time_utc':o['features']['end_time_utc'],'source_input_timezone':m['analysis_context']['input_timezone']}
            try:
                for field in ('start_time_utc','end_time_utc'):
                    if window[field] is not None:_time(window[field])
            except ValueError:
                raise PipelineError('INVALID_FEEDBACK_SOURCE') from None
            if o['object_key'] in seen or t['target'] != {k:o[k] for k in ('ip','protocol','local_port')} or t['observation_window'] != window:
                raise PipelineError('FEEDBACK_TASK_TARGET_MISMATCH')
            seen.add(o['object_key'])
    if count != original[0]['records'] or seen != set(targets):
        raise PipelineError('FEEDBACK_SOURCE_COUNT_MISMATCH')
    binding = {k:m[k] for k in ('tenant_id','project_id','dataset_id','network_namespace','test_fixture')}
    binding.update(source_run_id=m['run_id'],source_manifest_sha256=snapshots[result_dir/'manifest.json'][0],
        source_input_sha256=m['input_sha256'],source_observations_sha256=original[0]['sha256'],
        review_summary_sha256=snapshots[review_dir/'summary.json'][0],review_tasks_sha256=artifacts['review-tasks.jsonl']['sha256'])
    _unchanged(snapshots)
    return binding, tasks, snapshots


def _empty_model(reason):
    return dict(status='skipped',requested_groups=0,real_inference_count=0,successful_groups=0,failed_groups=0,skipped_groups=0,
        inference_seconds=0.,wall_seconds=0.,metadata=None,runtime=None,error_code=reason,completion_observed=False)


def _publish(output_dir, values, summary, snapshots):
    """Publish a new bounded result, summary last; never overwrite prior output."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=False); output_dir.chmod(0o700)
    stage = Path(tempfile.mkdtemp(prefix='.staging-', dir=output_dir))
    size = 0; artifacts = []
    for name, content, records in values:
        if not isinstance(content, str):
            content = json.dumps(content,ensure_ascii=False,allow_nan=False,indent=2)+'\n'
        raw = content.encode('utf-8'); size += len(raw)
        if size > MAX_OUTPUT_BYTES or (name=='feedback.json' and len(raw)>MAX_FEEDBACK_BYTES):
            raise PipelineError('FEEDBACK_OUTPUT_LIMIT', 4)
        with (stage/name).open('xb') as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        artifacts.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),records=records))
    summary['artifacts'] = artifacts
    validate_feedback(summary, 'summary')
    _unchanged(snapshots)
    write_json(stage/'summary.json', summary)
    for a in artifacts:
        os.replace(stage/a['path'], output_dir/a['path'])
    os.replace(stage/'summary.json', output_dir/'summary.json'); stage.rmdir()
    return summary


def _summary(binding, tasks, kind):
    return dict(schema_version=FEEDBACK_VERSION,component_version=VERSION,artifact_type=kind,status='success',exit_code=0,pipeline_complete=True,
        binding=binding,feedback_sha256=None,total_tasks=len(tasks),submitted_tasks=0,state_counts={},note_checks=0,
        model=_empty_model('NOT_REQUESTED'),experimental_notes=False,model_business_qualified=False,original_results_unchanged=True,
        review_required=True,task_closed=False,artifacts=[],limitations=[
            'Field completeness is not proof of correctness, attachment authenticity, ownership, exposure or authorization.',
            'References are recorded only; files and URLs in answers are never opened.',
            'All tasks remain pending human review. Original observations, candidates and priorities are immutable.',
            'Experimental text hints have no demonstrated business accuracy and never change material status.'])


def _task_label(task):
    target=task['target']
    if not target:return task['title']+'（整批资料）'
    protocol={6:'TCP',17:'UDP'}.get(target['protocol'],str(target['protocol']))
    return f"{task['title']} · {target['ip']} / {protocol} / {target['local_port'] or '端口不适用'}"


def _progress_text(rows, summary):
    labels={'AWAITING_FEEDBACK':'未回填','MATERIAL_INCOMPLETE':'缺项待补','INVALID_MATERIAL':'字段格式需要修正',
        'MATERIAL_CONFLICT':'声明与原上下文冲突','AWAITING_DEPENDENCY_MATERIAL':'待补前置材料',
        'FIELDS_COMPLETE_PENDING_REVIEW':'字段已齐，待人工核验'}
    errors={'NAT_MAPPING_FOR_TARGET_MISSING':'缺少该观察端点的NAT对应条目',
        'NAT_MAPPING_FOR_TARGET_AMBIGUOUS':'该观察端点匹配了多个NAT对应条目',
        'NAT_MAPPING_WINDOW_DOES_NOT_COVER_TARGET':'NAT对应表未覆盖观察时间窗',
        'NAT_TARGET_WINDOW_UNKNOWN':'原观察时间未知，无法核对NAT时间覆盖',
        'NAMESPACE_DECLARATION_CONFLICT':'申报网络空间与原分析不同，须人工确认并另建分析',
        'DECLARED_SCOPE_CONFLICT':'提供方声明范围存在冲突',
        'DUPLICATE_MAPPING_SOURCE':'同一NAT前端点重复申报',
        'PROTOCOL_PORT_MISMATCH':'协议与端口是否适用不一致',
        'INVALID_TIME_WINDOW':'开始时间晚于结束时间',
        'INVALID_SAMPLING_RATE':'采样方式与比例不一致',
        'UNKNOWN_SAMPLING_WITH_RATE':'采样未知时不能提供确定比例',
        'INVALID_FIELD_VALUE':'字段类型、格式或取值需要修正'}
    tasks={r['task']['task_id']:r['task'] for r in rows}
    lines=['# 复核材料进度', '', f"共有{len(rows)}项任务；所有任务仍待人工核验，原始事实和候选资格保持不变。", '',
        '文字模型：'+('实验调用'+str(summary['model']['real_inference_count'])+'次；提示不能证明材料真实。' if summary['experimental_notes'] else '未启用。'), '']
    lines += [f"- {labels[state]}：{count}项。" for state,count in summary['state_counts'].items()]
    lines.append('')
    for row in rows:
        task=row['task'];fields=feedback_schema()['$defs']['answers_'+task['task_kind']]['properties']
        def field_name(key):
            special={'provided_by':'材料提供人','submitted_at':'材料提交时间','sampling.mode':'采样方式'}
            return special.get(key,fields.get(key.split('.')[0],{}).get('title',key))
        lines += ['## '+_task_label(task),'', '状态：'+labels[row['material_status']]+'。建议提供方：'+task['owner_role']+'。']
        if row['missing_fields']:lines.append('待补：'+'；'.join(field_name(k) for k in row['missing_fields'])+'。')
        for error in row['field_errors']:
            lines.append('待核对：'+errors.get(error['code'],error['code'])+'（'+field_name(error['field'])+'）。')
        if row['blocked_by']:lines.append('前置材料：'+'、'.join(tasks[key]['title'] for key in row['blocked_by'])+'。')
        if row['material_status']=='FIELDS_COMPLETE_PENDING_REVIEW':lines.append('下一步：人工核验材料来源、真实性及适用范围；该状态不表示任务关闭。')
        for hint in row['model_hints']:
            lines.append('实验文字提示：'+('文字支持提示，仍需人工核验。' if hint['hint']=='TEXT_SUPPORT_SUGGESTED' else '未形成可采用的文字支持提示，保留人工核对。'))
        lines += ['任务引用：`'+task['task_id']+'`。','']
    return '\n'.join(lines)+'\n'


def create_feedback_template(result_dir, review_dir, *, output_dir):
    binding, tasks, snapshots = _source(result_dir, review_dir)
    responses = []; guide = ['# 复核材料回填', '', '复制 feedback.json 到独立文件后填写；每次评审写入新的输出目录。',
        'null表示尚未提供；保留task与binding原值。provided_by只是提供方声明，不能替代身份鉴权。',
        'supporting_evidence填写可核对的材料引用，本组件不会打开其文件或链接。note_checks默认留空。', '']
    for task in sorted(tasks.values(),key=lambda t:(t['work_order'],t['task_id'])):
        fields = feedback_schema()['$defs']['answers_'+task['task_kind']]['properties']
        responses.append(dict(task=task,provided_by=None,submitted_at=None,answers={k:None for k in fields},note_checks=[]))
        guide += ['## '+_task_label(task), '', f"任务：`{task['task_id']}`；建议提供方：{task['owner_role']}。",task['human_question'], '']
        for key,value in fields.items():
            shape=value['anyOf'][0]
            form=' / '.join(map(str,shape['enum'])) if 'enum' in shape else shape.get('type','有效值')
            if shape.get('type')=='object':form+='，字段：'+', '.join(shape['properties'])
            if shape.get('type')=='array' and shape['items'].get('type')=='object':form+='，条目字段：'+', '.join(shape['items']['properties'])
            guide.append(f"- `{key}`：{value['title']}；格式：{form}。")
        guide.append('')
    value = dict(schema_version=FEEDBACK_VERSION,binding=binding,responses=responses)
    validate_feedback(value, 'submission')
    summary = _summary(binding,tasks,'feedback_template')
    return _publish(output_dir,[('feedback.json',value,len(responses)),('FORM.md','\n'.join(guide)+'\n',None)],summary,snapshots)


def _time(value):
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})',value):
        raise ValueError('TIMEZONE_REQUIRED')
    result = datetime.fromisoformat(value.replace('Z','+00:00'))
    if result.tzinfo is None:
        raise ValueError('TIMEZONE_REQUIRED')
    return result


def _ip(value):
    address=ipaddress.ip_address(value)
    return str(getattr(address,'ipv4_mapped',None) or address)


def _nat_gap(task, answers):
    """Check the declared mapping covers this exact observed tuple and window."""
    target=task['target'];sides={'BEFORE_NAT':('pre',),'AFTER_NAT':('post',),'BOTH':('pre','post')}[answers['observation_view']]
    matches=[entry for entry in answers['nat_mapping'] if entry['protocol']==target['protocol'] and any(
        _ip(entry[side+'_ip'])==_ip(target['ip']) and entry[side+'_port']==target['local_port'] for side in sides)]
    if not matches:return 'NAT_MAPPING_FOR_TARGET_MISSING'
    if len(matches)>1:return 'NAT_MAPPING_FOR_TARGET_AMBIGUOUS'
    window=task['observation_window']
    if not window or not window['start_time_utc'] or not window['end_time_utc']:return 'NAT_TARGET_WINDOW_UNKNOWN'
    supplied=answers['mapping_time_window']
    if _time(supplied['start'])>_time(window['start_time_utc']) or _time(supplied['end'])<_time(window['end_time_utc']):
        return 'NAT_MAPPING_WINDOW_DOES_NOT_COVER_TARGET'
    return None


def _assess(task, response, binding):
    answers = response['answers'] if response else {}
    kind = task['task_kind']; schema = feedback_schema()['$defs']['answers_'+kind]
    missing = [k for k in schema['required_for_completeness'] if answers.get(k) is None]
    missing += [k for k in ('provided_by','submitted_at') if not response or response[k] is None]
    errors = [{'field':'.'.join(map(str,e.path)) or 'answers','code':'INVALID_FIELD_VALUE'} for e in islice(_validator('answers_'+kind).iter_errors(answers),20)]
    conflict = False
    if not errors:
        for field in ('mapping_time_window','observation_window'):
            if answers.get(field):
                try:
                    if _time(answers[field]['start']) > _time(answers[field]['end']):raise ValueError()
                except ValueError:
                    errors.append({'field':field,'code':'INVALID_TIME_WINDOW'})
        try:
            if kind=='scope':
                for cidr in answers.get('managed_cidrs') or []:
                    if '/' not in cidr:
                        raise ValueError()
                    ipaddress.ip_network(cidr,strict=True)
                if answers.get('network_namespace') is not None and answers['network_namespace'] != binding['network_namespace']:
                    conflict=True; errors.append({'field':'network_namespace','code':'NAMESPACE_DECLARATION_CONFLICT'})
                if answers.get('scope_confirmation')=='conflict':
                    conflict=True; errors.append({'field':'scope_confirmation','code':'DECLARED_SCOPE_CONFLICT'})
            if kind=='export':
                if answers.get('input_timezone') and answers['input_timezone']!='+08:00':
                    ZoneInfo(answers['input_timezone'])
                sampling=answers.get('sampling')
                if sampling:
                    if sampling['mode']=='unknown':
                        if sampling['rate'] is not None: errors.append({'field':'sampling.rate','code':'UNKNOWN_SAMPLING_WITH_RATE'})
                        missing.append('sampling.mode')
                    elif sampling['rate'] is None or (sampling['mode']=='unsampled' and sampling['rate']!=1):
                        errors.append({'field':'sampling.rate','code':'INVALID_SAMPLING_RATE'})
            if kind=='nat':
                seen=set()
                for item in answers.get('nat_mapping') or []:
                    key=(item['protocol'],_ip(item['pre_ip']),item['pre_port'])
                    if key in seen:
                        errors.append({'field':'nat_mapping','code':'DUPLICATE_MAPPING_SOURCE'})
                    seen.add(key)
                    if any((item[p] is None) == (item['protocol'] in (6,17)) for p in ('pre_port','post_port')):
                        errors.append({'field':'nat_mapping','code':'PROTOCOL_PORT_MISMATCH'})
        except (ValueError,ZoneInfoNotFoundError):
            field='managed_cidrs' if kind=='scope' else 'input_timezone' if kind=='export' else 'nat_mapping'
            errors.append({'field':field,'code':'INVALID_FIELD_VALUE'})
        for field in ('scope_confirmation','observation_view','business_role','external_access_need'):
            if answers.get(field) in ('unknown','UNKNOWN'):
                missing.append(field)
    has_material = bool(response and (response['provided_by'] is not None or response['submitted_at'] is not None or response['note_checks'] or any(v is not None for v in answers.values())))
    state = ('MATERIAL_CONFLICT' if conflict else 'INVALID_MATERIAL' if errors else
             'AWAITING_FEEDBACK' if not has_material else 'MATERIAL_INCOMPLETE' if missing else 'FIELDS_COMPLETE_PENDING_REVIEW')
    return dict(schema_version=FEEDBACK_VERSION,task=task,provided_by=response['provided_by'] if response else None,
        submitted_at=response['submitted_at'] if response else None,answers=answers,material_status=state,
        missing_fields=list(dict.fromkeys(missing)),field_errors=errors,blocked_by=[],
        note_checks=response['note_checks'] if response else [],model_hints=[],next_action='待补充材料。',
        review_required=True,task_closed=False,facts_changed=False,external_reachability='NOT_VERIFIED')


def review_feedback(result_dir, review_dir, feedback_path, *, output_dir, experimental_notes=False, laya=None, allow_rule_fallback=False):
    if type(experimental_notes) is not bool or type(allow_rule_fallback) is not bool or (allow_rule_fallback and not experimental_notes):
        raise PipelineError('INVALID_FEEDBACK_OPTIONS')
    if Path(output_dir).exists():
        raise FileExistsError(output_dir)
    binding, tasks, snapshots = _source(result_dir, review_dir)
    payload = _read_json(feedback_path,MAX_FEEDBACK_BYTES,snapshots)
    try:
        validate_feedback(payload,'submission')
    except (ValidationError,RecursionError):
        raise PipelineError('INVALID_FEEDBACK_SUBMISSION') from None
    if payload['binding'] != binding:
        raise PipelineError('FEEDBACK_BINDING_MISMATCH')
    responses={};checks=[]
    for response in payload['responses']:
        if response['submitted_at'] is not None:
            try:_time(response['submitted_at'])
            except ValueError:raise PipelineError('INVALID_FEEDBACK_TIMESTAMP') from None
        key=response['task']['task_id']
        if key not in tasks or key in responses or response['task'] != tasks[key]:
            raise PipelineError('FEEDBACK_TASK_MISMATCH')
        if len(json.dumps(response,ensure_ascii=False).encode()) > MAX_LINE_BYTES:
            raise PipelineError('FEEDBACK_ROW_LIMIT',4)
        ids=set()
        for check in response['note_checks']:
            if check['check_id'] in ids:
                raise PipelineError('DUPLICATE_NOTE_CHECK')
            ids.add(check['check_id'])
            checks.append({'id':digest([key,check['check_id']]),'note':check['note'],'claim':check['claim']})
        responses[key]=response
    if len(checks)>32:
        raise PipelineError('NOTE_CHECK_LIMIT',4)
    progress={key:_assess(task,responses.get(key),binding) for key,task in tasks.items()}
    for row in progress.values():
        row['blocked_by']=[key for key in row['task']['depends_on'] if progress[key]['material_status']!='FIELDS_COMPLETE_PENDING_REVIEW']
        if row['task']['target'] is not None:
            for dep in row['task']['depends_on']:
                parent=progress[dep]
                if parent['task']['task_kind']=='nat' and parent['material_status']=='FIELDS_COMPLETE_PENDING_REVIEW':
                    gap=_nat_gap(row['task'],parent['answers'])
                    if gap:
                        row['blocked_by'].append(dep)
                        row['field_errors'].append({'field':'depends_on.nat_mapping','code':gap})
        if row['material_status']=='FIELDS_COMPLETE_PENDING_REVIEW' and row['blocked_by']:
            row['material_status']='AWAITING_DEPENDENCY_MATERIAL'
        if row['field_errors']:
            row['next_action']='修正字段或核对冲突：'+', '.join(dict.fromkeys(e['field'] for e in row['field_errors']))+'。'
        elif row['missing_fields']:
            row['next_action']='请'+row['task']['owner_role']+'补充：'+', '.join(row['missing_fields'])+'。'
        elif row['blocked_by']:
            row['next_action']='本项字段已齐；先补齐所列前置任务的材料，再由人工核验。'
        else:
            row['next_action']='字段已齐，等待人工核验材料、适用范围与真实性；需要更新分析上下文时另建运行。'
    summary=_summary(binding,tasks,'feedback_review')
    summary.update(feedback_sha256=snapshots[Path(feedback_path)][0],note_checks=len(checks),experimental_notes=experimental_notes)
    hints={}
    if experimental_notes:
        hints,summary['model']=laya_adapter.check_notes(checks,laya)
        if summary['model']['status']=='failed':
            if not allow_rule_fallback:
                destination=Path(output_dir);destination.mkdir(parents=True,exist_ok=False);destination.chmod(0o700)
                write_json(destination/'failure.json',dict(schema_version=FEEDBACK_VERSION,status='failed',pipeline_complete=False,
                    error_code=summary['model']['error_code'],model=summary['model']))
                raise PipelineError(summary['model']['error_code'],3)
            summary.update(status='degraded',exit_code=5)
    for key,row in progress.items():
        for check in row['note_checks']:
            hint=hints.get(digest([key,check['check_id']]),dict(status='skipped',hint='UNRESOLVED',consistent=None,predictions=[],error_code='NOT_REQUESTED',experimental=True,changes_material_status=False))
            row['model_hints'].append(dict(check_id=check['check_id'],input_sha256=digest({'note':check['note'],'claim':check['claim']}),**hint))
        validate_feedback(row,'progress')
    summary['state_counts']=dict(Counter(r['material_status'] for r in progress.values()))
    summary['submitted_tasks']=sum(r['material_status']!='AWAITING_FEEDBACK' for r in progress.values())
    if summary['status']=='success' and any(r['material_status']!='FIELDS_COMPLETE_PENDING_REVIEW' for r in progress.values()):
        summary['status']='success_with_warnings'
    rows=sorted(progress.values(),key=lambda r:(r['task']['work_order'],r['task']['task_id']))
    lines=[];size=0
    for row in rows:
        line=json.dumps(row,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n'
        length=len(line.encode());size+=length
        if length>MAX_PROGRESS_LINE_BYTES or size>MAX_OUTPUT_BYTES:
            raise PipelineError('FEEDBACK_OUTPUT_LIMIT',4)
        lines.append(line)
    return _publish(output_dir,[('review-progress.jsonl',''.join(lines),len(rows)),('REVIEW.md',_progress_text(rows,summary),None)],summary,snapshots)


def load_feedback_result(directory, *, namespace, allow_test=False):
    """Validate a bounded result fully before returning any records to a consumer."""
    if type(allow_test) is not bool:
        raise PipelineError('INVALID_FEEDBACK_OPTIONS')
    directory=Path(directory); snapshots={}
    summary=_read_json(directory/'summary.json',1024*1024,snapshots)
    try:
        validate_feedback(summary,'summary')
    except ValidationError:
        raise PipelineError('INVALID_FEEDBACK_RESULT') from None
    if summary['artifact_type']!='feedback_review' or summary['status']=='degraded':
        raise PipelineError('FEEDBACK_CONSUMER_REQUIRES_COMPLETE_RESULT')
    if summary['binding']['network_namespace']!=namespace:
        raise PipelineError('FEEDBACK_NAMESPACE_MISMATCH')
    if summary['binding']['test_fixture'] and not allow_test:
        raise PipelineError('TEST_FIXTURE_FORBIDDEN')
    artifacts={a['path']:a for a in summary['artifacts']}
    if summary['total_tasks']>MAX_TASKS or len(summary['artifacts'])!=2 or set(artifacts)!={'review-progress.jsonl','REVIEW.md'}:
        raise PipelineError('INVALID_FEEDBACK_RESULT')
    artifact=artifacts['review-progress.jsonl'];path=directory/'review-progress.jsonl'
    for name,a in artifacts.items():_bind_artifact(directory/name,a,MAX_OUTPUT_BYTES,snapshots)
    rows=[];ids=set()
    for row in _lines(path,MAX_PROGRESS_LINE_BYTES):
        try:
            validate_feedback(row,'progress')
        except ValidationError:
            raise PipelineError('INVALID_FEEDBACK_RESULT') from None
        t=row['task']
        if t['task_id'] in ids or t['source_run_id']!=summary['binding']['source_run_id'] or t['test_fixture']!=summary['binding']['test_fixture']:
            raise PipelineError('INVALID_FEEDBACK_RESULT')
        ids.add(t['task_id']);rows.append(row)
        if len(rows)>MAX_TASKS:raise PipelineError('FEEDBACK_TASK_LIMIT',4)
    if len(rows)!=summary['total_tasks'] or len(rows)!=artifact['records'] or dict(Counter(r['material_status'] for r in rows))!=summary['state_counts']:
        raise PipelineError('FEEDBACK_SOURCE_COUNT_MISMATCH')
    _unchanged(snapshots)
    return summary,rows
