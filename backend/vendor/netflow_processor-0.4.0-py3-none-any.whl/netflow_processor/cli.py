import argparse
from dataclasses import replace
import json
from pathlib import Path
import sys

from .api import process_file
from .contracts import PipelineError, ProcessingContext, ProcessorConfig, read_json
from .laya_adapter import doctor


def main(argv=None):
    p = argparse.ArgumentParser(prog='netflow-process', description='NetFlow evidence processing; never scans or verifies reachability.')
    sub = p.add_subparsers(dest='command', required=True)
    analyze = sub.add_parser('analyze')
    analyze.add_argument('--input', type=Path, required=True)
    analyze.add_argument('--profile', choices=('raw','exposure','exposure-raw-v1'), required=True)
    analyze.add_argument('--context', type=Path, required=True)
    analyze.add_argument('--config', type=Path)
    analyze.add_argument('--mode', choices=('rules','assisted'), default='rules', help='Defaults to rules; assisted role classification is an explicit experiment')
    analyze.add_argument('--output', type=Path, required=True)
    analyze.add_argument('--allow-rule-fallback', action='store_true', default=None)
    health = sub.add_parser('doctor')
    health.add_argument('--config', type=Path, required=True)
    evaluation = sub.add_parser('evaluate')
    evaluation.add_argument('--cases', type=Path, required=True)
    evaluation.add_argument('--config', type=Path, required=True)
    evaluation.add_argument('--output', type=Path, required=True)
    triage = sub.add_parser('triage',help='Describe observed behaviors and consolidate human review tasks')
    triage.add_argument('--result',type=Path,required=True)
    triage.add_argument('--context-notes',type=Path)
    triage.add_argument('--output',type=Path,required=True)
    template = sub.add_parser('feedback-template', help='Create a structured form bound to immutable source and review results')
    feedback = sub.add_parser('review-feedback', help='Validate human material declarations; never close tasks or alter candidates')
    for command in (template, feedback):
        command.add_argument('--result', type=Path, required=True)
        command.add_argument('--review', type=Path, required=True)
        command.add_argument('--output', type=Path, required=True)
    feedback.add_argument('--feedback', type=Path, required=True)
    feedback.add_argument('--experimental-notes', action='store_true', help='Explicitly run the unqualified local Laya note/claim experiment')
    feedback.add_argument('--config', type=Path)
    feedback.add_argument('--allow-rule-fallback', action='store_true')
    args = p.parse_args(argv)
    try:
        if args.command == 'feedback-template':
            from .feedback import create_feedback_template
            result=create_feedback_template(args.result,args.review,output_dir=args.output)
            print(json.dumps({'status':result['status'],'total_tasks':result['total_tasks']}),file=sys.stderr)
            return result['exit_code']
        if args.command == 'review-feedback':
            from .feedback import review_feedback
            config=ProcessorConfig.from_dict(read_json(args.config)) if args.config else ProcessorConfig()
            config.validate()
            result=review_feedback(args.result,args.review,args.feedback,output_dir=args.output,
                experimental_notes=args.experimental_notes,laya=config.laya,allow_rule_fallback=args.allow_rule_fallback)
            print(json.dumps({'status':result['status'],'state_counts':result['state_counts'],
                              'real_inference_count':result['model']['real_inference_count']}),file=sys.stderr)
            return result['exit_code']
        if args.command == 'triage':
            from .triage import triage_result
            result=triage_result(args.result,output_dir=args.output,context_notes=read_json(args.context_notes) if args.context_notes else None)
            print(json.dumps({'status':result['status'],'observations':result['observations'],'review_tasks':result['total_review_tasks']}),file=sys.stderr)
            return 0
        cfg = ProcessorConfig.from_dict(read_json(args.config)) if args.config else ProcessorConfig()
        cfg.validate()
        if args.command == 'doctor':
            result = doctor(cfg.laya)
            print(json.dumps(result), file=sys.stderr)
            return 0 if result['status']=='configured' else 3
        if args.command == 'evaluate':
            from .evaluation import evaluate
            result = evaluate(args.cases, cfg, args.output)
            print(json.dumps({'status':result['status'],'report':str(args.output/'evaluation.json')}), file=sys.stderr)
            return 0 if result['status']=='success' else 3
        ctx = ProcessingContext.from_dict(read_json(args.context))
        cfg = replace(cfg, input_profile=args.profile, mode=args.mode,
                      allow_rule_fallback=cfg.allow_rule_fallback if args.allow_rule_fallback is None else args.allow_rule_fallback)
        result = process_file(args.input, context=ctx, config=cfg, output_dir=args.output)
        print(json.dumps({'status':result.manifest['status'], 'counts':result.manifest['counts'], 'errors':result.manifest['errors']}), file=sys.stderr)
        return result.exit_code
    except PipelineError as e:
        print(json.dumps({'status':'failed','error_code':e.code}), file=sys.stderr)
        return e.exit_code
    except FileExistsError:
        print('{"status":"failed","error_code":"OUTPUT_ALREADY_EXISTS"}', file=sys.stderr)
        return 2
    except (OSError, ValueError, TypeError):
        print('{"status":"failed","error_code":"INVALID_INPUT_OR_LOCAL_IO"}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
