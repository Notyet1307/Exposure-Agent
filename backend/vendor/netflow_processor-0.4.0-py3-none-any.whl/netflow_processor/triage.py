"""Evidence-backed review planning over an immutable processor result.

Behavior labels describe observations. They do not change role, scope, candidate
eligibility or reachability. Shared missing context becomes a batch task.
"""
from collections import Counter
from importlib.resources import files
import hashlib
import json
import os
from pathlib import Path
import tempfile

from jsonschema import Draft202012Validator, ValidationError

from .contracts import VERSION, PipelineError, digest, read_json, validate_document
from .outputs import write_json

TRIAGE_VERSION='netflow-review-v1'
POLICY_VERSION='netflow-review-policy-v2'
MAX_SOURCE_BYTES=268_435_456
MAX_SOURCE_LINE_BYTES=65_536
MAX_SOURCE_ITEMS=100_000
# Analyst-selected hints, not application identification or a port-based role rule.
MANAGEMENT_PORTS={22:'SSH',23:'Telnet',445:'SMB',1433:'MS-SQL',3306:'MySQL',3389:'RDP',5432:'PostgreSQL',5900:'RFB/VNC',6379:'Redis'}
PORT_HINTS={(6,p):name for p,name in MANAGEMENT_PORTS.items()} | {
    (6,80):'HTTP',(6,443):'HTTPS',(17,443):'HTTPS',
    (6,53):'DNS',(17,53):'DNS',(17,123):'NTP',
    (6,25):'SMTP',(6,465):'邮件提交',(6,587):'邮件提交',
    (6,110):'POP3',(6,995):'POP3S',(6,143):'IMAP',(6,993):'IMAPS',
}
TAG_LABELS={
    'MULTI_PEER_DESTINATION':'多对端指向同一本地端口',
    'MULTI_PEER_SOURCE':'同一源侧本地端口关联多个对端',
    'SOURCE_REPEATED_SERVICE_PORT':'源侧常见服务端口重复关联多个外侧对端',
    'ADDRESS_SIDE_CROSSOVER':'此地址在两列均出现，按行保留角色',
    'MULTI_PEER_BOTH_SIDES':'多对端活动同时出现在源侧和目的侧',
    'REVERSE_TUPLE':'观测到反向五元组共现',
    'SYN_ONLY_BITS':'已知TCP记录仅见SYN标志',
    'RST_BITS':'观测到TCP复位标志',
    'ACK_OR_PSH_BITS':'观测到TCP确认或PSH标志',
    'UDP_ACTIVITY':'UDP端口活动，角色尚未确认',
    'OTHER_PROTOCOL':'非TCP/UDP活动或缺少适用端口',
    'SINGLE_RECORD':'仅一条记录，重复行为证据不足',
    'SPARSE_ACTIVITY':'少量活动，角色证据待补',
    'MANAGEMENT_PORT_HINT':'常见管理或数据库端口提示',
    'REGISTERED_PORT_HINT':'常见服务端口提示，未识别实际应用协议',
    'LEGACY_SERVER_HINT':'原规则给出服务端倾向',
}
_SCHEMA=None
_VALIDATORS={}


def validate_review(value,kind):
    global _SCHEMA
    if _SCHEMA is None:
        _SCHEMA=json.loads(files('netflow_processor').joinpath('schemas/netflow-review-v1.json').read_text())
    if kind not in _VALIDATORS:
        _VALIDATORS[kind]=Draft202012Validator(_SCHEMA|{'$ref':'#/$defs/'+kind})
    _VALIDATORS[kind].validate(value)


def reject_constant(_):
    raise ValueError('NONFINITE_JSON')


def describe_observation(o):
    f=o['features'];n=f['record_count'];flags=f['tcp_flags_union'];tags=[]
    if n<=0:raise PipelineError('INVALID_TRIAGE_SOURCE')
    if f['reverse_tuple_count']>0:tags.append('REVERSE_TUPLE')
    if f['peer_count']>=2:
        if f['destination_count']/n>=.8:tags.append('MULTI_PEER_DESTINATION')
        elif f['source_count']/n>=.8:tags.append('MULTI_PEER_SOURCE')
        else:tags.append('MULTI_PEER_BOTH_SIDES')
    if o['protocol']==6 and flags is not None:
        if flags==2:tags.append('SYN_ONLY_BITS')
        if flags&4:tags.append('RST_BITS')
        if flags&24:tags.append('ACK_OR_PSH_BITS')
    if o['protocol']==17:tags.append('UDP_ACTIVITY')
    if o['protocol'] not in (6,17) or o['local_port'] is None:tags.append('OTHER_PROTOCOL')
    if n==1:tags.append('SINGLE_RECORD')
    if not tags:tags.append('SPARSE_ACTIVITY')
    hint=PORT_HINTS.get((o['protocol'],o['local_port']))
    management_hint=o['protocol']==6 and o['local_port'] in MANAGEMENT_PORTS
    if hint:tags.append('REGISTERED_PORT_HINT')
    source_only=f.get('source_column_only',False)
    if source_only and hint and n>=2 and f['peer_count']>=2 and f['local_port_share']>=.6:
        tags.append('SOURCE_REPEATED_SERVICE_PORT')
    if f.get('address_side_crossover'):tags.append('ADDRESS_SIDE_CROSSOVER')
    if management_hint:tags.append('MANAGEMENT_PORT_HINT')
    if o['rule_role']=='server_like':tags.append('LEGACY_SERVER_HINT')
    if management_hint and (not source_only or 'SOURCE_REPEATED_SERVICE_PORT' in tags):
        category='MANAGEMENT_PORT_HINT';question='先核对归属和NAT映射，再确认该端口实际运行的服务与对外访问需求。'
    elif o['rule_role']=='server_like' or 'MULTI_PEER_DESTINATION' in tags or 'SOURCE_REPEATED_SERVICE_PORT' in tags:
        category='SERVICE_PATTERN_REVIEW';question='确认这个观察端点是否对应本方服务，核对实际监听业务及访问控制。'
    elif 'SYN_ONLY_BITS' in tags or 'RST_BITS' in tags:
        category='TCP_CONTROL_REVIEW';question='结合已有设备日志确认连接尝试或复位原因，并核对是否因采样、超时或导出筛选缺少另一方向。'
    elif source_only and hint:
        category='SOURCE_SERVICE_PORT_HINT';question='源侧端口匹配常见服务提示，但重复证据不足；集中核对业务用途，不据此认定服务。'
    elif 'MULTI_PEER_SOURCE' in tags:
        category='SOURCE_PATTERN_REVIEW';question='核对这组源侧活动的业务用途，区分主动访问、服务发送和NAT汇聚。'
    else:
        category='ACTIVITY_EVIDENCE_POOL';question='归入活动证据池；优先补充同一观察点连续窗口及采集语义，不逐条猜测业务角色。'
    priority=1 if category in ('MANAGEMENT_PORT_HINT','SERVICE_PATTERN_REVIEW') else 2 if category in ('TCP_CONTROL_REVIEW','SOURCE_PATTERN_REVIEW','SOURCE_SERVICE_PORT_HINT') else 3
    if source_only and category in ('MANAGEMENT_PORT_HINT','SOURCE_PATTERN_REVIEW'):
        question='按已确认的本方源侧定位业务，核对实际用途、监听配置和访问需求；源侧可能是客户端请求或服务响应。'
    if o['final_recommendation']=='EXCLUDE_BY_RULE':
        category='RULE_EXCLUDED';priority=3;question='保留原始排除依据，不创建本方外部服务核查任务。'
    evidence_level='bidirectional_observation' if f['reverse_tuple_count'] else 'repeated_observation' if n>=2 else 'single_observation'
    fact=(f"{n}条源侧记录，{f['peer_count']}个外侧对端；固定源列视图未评估反向匹配。" if source_only else
          f"{n}条流记录，{f['peer_count']}个对端；源侧{f['source_count']}条、目的侧{f['destination_count']}条；反向组合{f['reverse_tuple_count']}个。")
    return dict(behavior_tags=tags,behavior_labels=[TAG_LABELS[t] for t in tags],review_category=category,
                review_order=priority,evidence_level=evidence_level,service_port_hint=hint,
                human_question=question,observed_fact_zh=fact,
                interpretation_limit_zh='端口只是服务提示。TCP flags是汇总位集合，不证明包顺序、握手成功或公网可达；方向为导出记录方向。')


TASKS={
 'scope':('确认本方地址范围','网络或资产负责人','哪些观察地址属于本方，分别位于哪个网络空间？',
          ['受管CIDR或准确IP清单','网络空间与归属依据'],['managed_cidrs','network_namespace','scope_confirmation'],
          '提供可核对范围，不以运营商名称或IP出现替代所有权。'),
 'nat':('补充NAT对应关系','NAT或边界网络管理员','这些观察地址和端口在NAT前后分别对应什么端点，哪个时间窗有效？',
        ['翻译前后IP与端口','映射有效时间或事件时间','采集点位于NAT哪一侧'],['nat_mapping','mapping_time_window','observation_view'],
        '能将目标观察IP/协议/端口在对应时间关联到实际业务端点。'),
 'export':('核对采集与导出语义','采集平台维护人员','方向、IN/OUT计数、flags、采样和时区如何定义，当前文件怎样选取？',
           ['导出模板或字段说明','采样率及计数是否已估算','采集视角与时间基准','样本选取方法'],['sampling','input_timezone','counter_semantics','export_selection'],
           '已说明字段与方向含义；不将OUT为零、sampler ID或汇总flags当作缺失事实的替代。'),
 'coverage':('补充连续观测窗口','数据提供方','能否提供同一观察点、同一范围下更连续的导出，帮助核对重复行为及反向流量？',
             ['连续时间窗口的导出','过滤或截取条件','方向覆盖说明'],['additional_dataset','coverage_notes'],
             '补充资料有明确窗口与来源，不必承诺一定出现反向流量。'),
 'tcp':('集中核对TCP尝试与复位特征','网络运维或业务运维','仅见SYN或带RST标志的活动来自什么业务，是否受采样、ACL、超时或导出方式影响？',
        ['相关设备现有日志','业务访问控制配置','采集覆盖说明'],['cause_assessment','supporting_evidence'],
        '给出有依据的解释或仍未解决的原因；不能仅凭flags定为攻击、故障或开放端口。'),
 'source':('核对多对端源侧活动用途','业务负责人','这些活动是主动访问、服务发送还是NAT汇聚后的多业务流量？',
           ['业务通信需求','必要的NAT对应关系','已有业务或网络日志'],['business_role','business_purpose','supporting_evidence'],
           '标签有独立业务依据，不使用当前规则或模型输出反填真值。'),
 'service':('核对具体服务与开放需求','业务负责人及网络管理员','该观察端点是否对应本方服务，实际协议是什么，是否需要对外提供？',
            ['归属与NAT对应关系','服务清单或监听配置','对外访问需求与访问控制'],['business_role','actual_service','external_access_need','supporting_evidence'],
            '明确对应业务、角色与访问需求；本任务不自动扫描、创建资产或确认公网可达。'),
}


def triage_result(result_dir, *, output_dir, context_notes=None):
    result_dir,output_dir=Path(result_dir),Path(output_dir)
    notes={} if context_notes is None else context_notes
    if not isinstance(notes,dict) or set(notes)-{'nat_present','external_interaction_user_confirmed','export_platform_known'} or any(v is not None and type(v) is not bool for v in notes.values()):
        raise PipelineError('INVALID_TRIAGE_CONTEXT_NOTES')
    m=read_json(result_dir/'manifest.json')
    try:validate_document(m,'manifest')
    except ValidationError:raise PipelineError('INVALID_SOURCE_MANIFEST') from None
    if m['status'] not in ('success','success_with_warnings') or not m['pipeline_complete']:
        raise PipelineError('TRIAGE_REQUIRES_COMPLETE_RESULT')
    source=result_dir/'observations.jsonl'
    items=[a for a in m['artifacts'] if a['path']=='observations.jsonl']
    if len(items)!=1:raise PipelineError('INVALID_SOURCE_ARTIFACT')
    source_limit=min(MAX_SOURCE_BYTES,m['limits']['max_output_bytes'])
    def source_hash():
        h=hashlib.sha256();size=0
        with source.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):
                size+=len(block)
                if size>source_limit:raise PipelineError('TRIAGE_SOURCE_LIMIT',4)
                h.update(block)
        if size!=items[0]['bytes']:raise PipelineError('SOURCE_ARTIFACT_CHANGED')
        return h.hexdigest()
    if source_hash()!=items[0]['sha256']:raise PipelineError('SOURCE_ARTIFACT_CHANGED')
    output_dir.mkdir(parents=True,exist_ok=False);output_dir.chmod(0o700)
    stage=Path(tempfile.mkdtemp(prefix='.staging-',dir=output_dir))
    ctx=m['analysis_context'];limit=m['limits']['max_output_bytes'];written_bytes=0
    counts=Counter();tag_counts=Counter();category_counts=Counter();tasks=Counter();shared=[]
    identity=[m['tenant_id'],m['project_id'],m['network_namespace'],m['dataset_id']]
    def task_id(kind,key='batch'):return 'task:'+digest(identity+[POLICY_VERSION,kind,key])
    if ctx['scope_confirmation']!='confirmed':shared.append('scope')
    if notes.get('nat_present') is True or ctx['observation_point']['nat_context'] in ('mapped','unknown'):shared.append('nat')
    if notes.get('export_platform_known') is not True or ctx['sampling']['mode']=='unknown' or ctx['observation_point']['view']=='UNKNOWN':shared.append('export')
    task_objects=Counter()
    handles={n:(stage/n).open('w',encoding='utf-8') for n in ('enriched-observations.jsonl','review-tasks.jsonl')}
    def emit(name,value,kind):
        nonlocal written_bytes
        validate_review(value,kind)
        line=json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n'
        size=len(line.encode())
        if written_bytes+size>limit:raise PipelineError('TRIAGE_OUTPUT_LIMIT',4)
        handles[name].write(line);written_bytes+=size
    def make_task(kind,count,*,object_key=None,source_refs=None,observation=None):
        title,owner,question,material,fields,done=TASKS[kind]
        if ctx.get('endpoint_selection')=='declared_source' and 'nat' not in shared:
            if kind=='source':
                title='集中核对源侧业务用途'
                question='本方源侧已确认；这些活动属于客户端访问、服务响应还是其他业务？端口提示是否符合实际业务？'
                material=['业务通信需求','已有业务或网络日志']
            elif kind=='service':
                material=['本方源侧地址对应业务','服务清单或监听配置','对外访问需求与访问控制']
            elif kind=='export':
                question='本批次源列为本方内侧、目的列为外侧且地址未转换已确认；继续核对计数、flags、采样、时区、采集位置和导出选取方法。'
        depends=[task_id(k) for k in shared] if kind not in shared else []
        return dict(schema_version=TRIAGE_VERSION,task_id=task_id(kind,object_key or 'batch'),task_kind=kind,
                    title=title,owner_role=owner,human_question=question,required_material=material,return_fields=fields,
                    completion_criteria=done,applies_to_count=count,object_key=object_key,source_refs=source_refs or [],
                    depends_on=depends,status='awaiting_context' if depends else 'pending_review',
                    work_order=0 if kind in shared else 1 if kind=='service' else 2,
                    task_scope='object' if object_key else 'dataset',source_run_id=m['run_id'],test_fixture=m['test_fixture'],
                    target=({k:observation[k] for k in ('ip','protocol','local_port')} if observation else None),
                    observation_window=({'start_time_utc':observation['features']['start_time_utc'],
                                         'end_time_utc':observation['features']['end_time_utc'],
                                         'source_input_timezone':ctx['input_timezone']} if observation else None),
                    creates_asset=False,external_action_authorized=False)
    try:
        with source.open('rb') as f:
            while line:=f.readline(MAX_SOURCE_LINE_BYTES+1):
                if len(line)>MAX_SOURCE_LINE_BYTES:raise PipelineError('TRIAGE_SOURCE_LIMIT',4)
                o=json.loads(line,parse_constant=reject_constant)
                validate_document(o,'observation')
                if len(o['source_refs'])>min(20,m['limits']['max_evidence_refs_per_item']):
                    raise PipelineError('TRIAGE_SOURCE_LIMIT',4)
                if any(o[k]!=m[k] for k in ('tenant_id','project_id','dataset_id','network_namespace','test_fixture')):
                    raise PipelineError('SOURCE_CONTEXT_MISMATCH')
                counts['observations']+=1
                if counts['observations']>min(MAX_SOURCE_ITEMS,m['limits']['max_output_items']):raise PipelineError('TRIAGE_ITEMS_LIMIT',4)
                description=describe_observation(o);tags=description['behavior_tags'];category=description['review_category']
                tag_counts.update(tags);category_counts[category]+=1
                refs=[task_id(k) for k in shared]
                if o['features']['record_count']==1:
                    task_objects['coverage']+=1;refs.append(task_id('coverage'))
                if category=='TCP_CONTROL_REVIEW':task_objects['tcp']+=1;refs.append(task_id('tcp'))
                if category in ('SOURCE_PATTERN_REVIEW','SOURCE_SERVICE_PORT_HINT'):task_objects['source']+=1;refs.append(task_id('source'))
                if category in ('MANAGEMENT_PORT_HINT','SERVICE_PATTERN_REVIEW'):
                    task=make_task('service',1,object_key=o['object_key'],source_refs=o['source_refs'],observation=o)
                    emit('review-tasks.jsonl',task,'task');tasks['service']+=1;refs.append(task['task_id'])
                result=dict(schema_version=TRIAGE_VERSION,policy_version=POLICY_VERSION,object_key=o['object_key'],
                    ip=o['ip'],ip_version=o['ip_version'],protocol=o['protocol'],local_port=o['local_port'],
                    source_run_id=m['run_id'],source_refs=o['source_refs'],source_refs_omitted=o['source_refs_omitted'],
                    original_rule_role=o['rule_role'],original_model_role=o['model_role'],
                    original_recommendation=o['final_recommendation'],scope_eligibility=o['scope_eligibility'],
                    external_reachability='NOT_VERIFIED',test_fixture=m['test_fixture'],model_review_hint=None,
                    observed_start_time_utc=o['features']['start_time_utc'],observed_end_time_utc=o['features']['end_time_utc'],
                    facts={k:o['features'][k] for k in ('record_count','peer_count','source_count','destination_count','reverse_tuple_count','local_port_share','tcp_flags_union','flags_known_records','source_column_only','address_side_crossover') if k in o['features']},
                    review_task_ids=list(dict.fromkeys(refs)),**description)
                emit('enriched-observations.jsonl',result,'observation')
        if counts['observations']!=items[0]['records']:raise PipelineError('SOURCE_ARTIFACT_COUNT_MISMATCH')
        if source_hash()!=items[0]['sha256']:raise PipelineError('SOURCE_ARTIFACT_CHANGED_DURING_TRIAGE')
        for kind in shared:
            emit('review-tasks.jsonl',make_task(kind,counts['observations']),'task');tasks[kind]+=1
        for kind,count in task_objects.items():
            emit('review-tasks.jsonl',make_task(kind,count),'task');tasks[kind]+=1
    except (ValidationError,ValueError,KeyError):
        raise PipelineError('INVALID_TRIAGE_SOURCE') from None
    finally:
        for f in handles.values():f.flush();os.fsync(f.fileno());f.close()
    artifacts=[]
    for name in handles:
        p=stage/name;fh=hashlib.sha256()
        with p.open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):fh.update(block)
        artifacts.append(dict(path=name,bytes=p.stat().st_size,sha256=fh.hexdigest()))
    summary=dict(schema_version=TRIAGE_VERSION,policy_version=POLICY_VERSION,component_version=VERSION,
        status='success',pipeline_complete=True,source_run_id=m['run_id'],source_input_sha256=m['input_sha256'],
        source_observations_sha256=items[0]['sha256'],test_fixture=m['test_fixture'],context_notes=notes,
        observations=counts['observations'],behavior_counts=dict(tag_counts),category_counts=dict(category_counts),
        task_counts=dict(tasks),total_review_tasks=sum(tasks.values()),
        model_calls=0,model_triage_enabled=False,original_recommendations_unchanged=True,artifacts=artifacts,
        limits=['Behavior is observed evidence, not identified application or public reachability.',
                'Review order is an explicit policy, not a calibrated risk score.',
                'external_interaction_user_confirmed is retained as a user statement only; it does not change role, scope, task planning or reachability.',
                'Shared tasks consolidate missing context; reduced task count is not measured human-time savings.'])
    validate_review(summary,'summary');write_json(stage/'summary.json',summary)
    for a in artifacts:os.replace(stage/a['path'],output_dir/a['path'])
    os.replace(stage/'summary.json',output_dir/'summary.json');stage.rmdir()
    return summary
