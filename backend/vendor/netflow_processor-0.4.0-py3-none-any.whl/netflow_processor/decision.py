"""Rules own facts and hard gates; model outputs only modify local suggestions."""
from .contracts import RULE_VERSION, SCHEMA_VERSION

REASONS = {
    'INTERNAL_ONLY': '仅有内部通信，不构成外部服务线索。',
    'INTERNAL_VIEW': '观察点为内部视角，不形成外部核查候选。',
    'SPECIAL_ADDRESS': '特殊或保留地址不具备本合同的公网候选资格。',
    'SCOPE_UNKNOWN': '范围尚未确认，需要调用方补充。',
    'SOURCE_POSITION_ONLY': '本批次源列已声明为本方内侧；该声明不构成资产纳管、服务角色或外部核查授权。',
    'SOURCE_ROLE_NOT_DETERMINED_BY_COLUMN': '固定内到外列方向不代表连接发起方；源端口也可能属于服务响应。',
    'SOURCE_REVERSE_NOT_EVALUATED': '固定源侧视图不进行跨列反向匹配，不能据此判断是否存在返回流量。',
    'ADDRESS_SIDE_CROSSOVER': '同一地址在本批次两列均出现；各行角色独立保留，不合并两侧证据。',
    'SCOPE_CONFLICT': '调用方范围存在冲突，保留诊断并阻止成功发布与候选提升。',
    'VIEW_UNKNOWN': '观察视角不明，需要补充。',
    'NAT_UNRESOLVED': '尚无可核查的端点级 NAT 对应关系。',
    'NO_EXTERNAL_PEER_EVIDENCE': '未记录到符合本合同的外部对端证据。',
    'MISSING_SERVICE_PORT': '没有适用且有效的服务端口。',
    'MISSING_TIME': '时间证据缺失，需补充后核查。',
    'MISSING_FLAGS': 'TCP flags 缺失，不推断握手顺序。',
    'STABLE_PORT_MULTIPLE_PEERS': '本地端口重复出现在多对端活动中，具有服务端倾向。',
    'VARYING_LOCAL_PORTS': '主机本地端口分散并呈发起方模式，具有客户端倾向。',
    'ROLE_CONFLICT': '服务端与客户端方向证据冲突。',
    'INSUFFICIENT_ROLE_EVIDENCE': '角色证据不足。',
    'EXTERNAL_PEER_ACTIVITY': '存在范围外对端活动；对端不作为本方候选。',
    'NO_REVERSE_TUPLE': '没有匹配到反向五元组证据，不能推断可达或握手。',
    'SAMPLING_UNKNOWN': '采样参数未知，计数仅代表输入记录。',
    'MODEL_SERVER_SUPPORT': '模型给出服务端建议，仅用于安排进一步核查。',
    'RULE_MODEL_CONFLICT': '规则与模型冲突，保留人工复核。',
    'MODEL_CLIENT_REVIEW': '模型倾向客户端，降低复核优先级但不删除。',
    'MODEL_UNCERTAIN': '模型给出混合或未知角色，需要复核。',
    'MODEL_FAILURE': '模型执行失败；仅按显式策略降级或报告失败。',
    'RULES_ONLY': '当前使用确定性规则建议。',
}


def baseline(obj, ctx, cfg):
    f, p = obj['features'], cfg.policy
    reasons, exclude, review = [], [], []
    source_only = ctx.endpoint_selection == 'declared_source'
    if source_only:
        review.append('SOURCE_POSITION_ONLY')
    if not source_only and not obj['address_public_eligible']:
        exclude.append('SPECIAL_ADDRESS')
    if not source_only and f['internal_peer_records'] == f['record_count']:
        exclude.append('INTERNAL_ONLY')
    if not source_only and ctx.observation_point['view'] == 'INTERNAL':
        exclude.append('INTERNAL_VIEW')
    if ctx.scope_confirmation != 'confirmed':
        review.append('SCOPE_CONFLICT' if ctx.scope_confirmation == 'conflict' else 'SCOPE_UNKNOWN')
    if ctx.observation_point['view'] == 'UNKNOWN':
        review.append('VIEW_UNKNOWN')
    if ctx.observation_point['nat_context'] not in ('none', 'explicit_no_nat_in_fixture'):
        review.append('NAT_UNRESOLVED')
    if not f['external_peer_records']:
        review.append('NO_EXTERNAL_PEER_EVIDENCE')
    if obj['local_port'] is None:
        review.append('MISSING_SERVICE_PORT')
    if f['start_missing_records'] or f['end_missing_records']:
        review.append('MISSING_TIME')
    if obj['protocol'] == 6 and f['flags_known_records'] < f['record_count']:
        reasons.append('MISSING_FLAGS')
    server = (obj['local_port'] is not None and f['record_count'] >= p['min_service_records']
              and f['peer_count'] >= p['min_service_peers'] and f['local_port_share'] >= p['stable_port_ratio']
              and (f['reverse_tuple_count'] > 0 or f['destination_syn_without_ack_records'] > 0 or f['source_syn_ack_records'] > 0))
    client = (f['host_distinct_local_ports'] >= p['min_client_ports'] and f['host_top_port_ratio'] <= p['client_top_port_ratio']
              and f['source_count'] > 0 and (obj['protocol'] == 17 or f['source_syn_without_ack_records'] > 0))
    conflicting = server and f['source_syn_without_ack_records'] > 0 and f['destination_syn_without_ack_records'] > 0
    role = 'mixed' if (server and client) or conflicting else 'server_like' if server else 'client_like' if client else 'unknown'
    if source_only:
        role = 'unknown'
        reasons.append('SOURCE_ROLE_NOT_DETERMINED_BY_COLUMN')
        if f['address_side_crossover']:
            reasons.append('ADDRESS_SIDE_CROSSOVER')
    reasons += [{'server_like':'STABLE_PORT_MULTIPLE_PEERS','client_like':'VARYING_LOCAL_PORTS','mixed':'ROLE_CONFLICT','unknown':'INSUFFICIENT_ROLE_EVIDENCE'}[role]]
    if f['external_peer_records']:
        reasons.append('EXTERNAL_PEER_ACTIVITY')
    if source_only:
        reasons.append('SOURCE_REVERSE_NOT_EVALUATED')
    elif not f['reverse_tuple_count']:
        reasons.append('NO_REVERSE_TUPLE')
    if ctx.sampling['mode'] == 'unknown':
        reasons.append('SAMPLING_UNKNOWN')
    return {'role':role, 'exclude':exclude, 'review':review, 'reasons':reasons}


def fuse(obj, rule, model, ctx, cfg):
    role, status = model['role'], model['status']
    reasons = rule['exclude'] + rule['review'] + rule['reasons']
    source, adopted, blocked, priority = 'rules', False, False, 'normal'
    if rule['exclude']:
        recommendation = 'EXCLUDE_BY_RULE'
        source = 'hard_rule'
        blocked = status == 'success'
    elif rule['review']:
        recommendation = 'REVIEW_REQUIRED'
        source = 'hard_rule'
        blocked = status == 'success'
    elif status == 'failed':
        recommendation = 'VERIFY_CANDIDATE' if cfg.allow_rule_fallback and rule['role']=='server_like' else 'REVIEW_REQUIRED'
        source = 'rule_fallback' if cfg.allow_rule_fallback else 'model_failure'
        reasons.append('MODEL_FAILURE')
    elif status == 'success':
        source, adopted = 'assisted', True
        if (rule['role']=='server_like' and role=='client_like') or (rule['role']=='client_like' and role=='server_like'):
            recommendation = 'REVIEW_REQUIRED'
            reasons.append('RULE_MODEL_CONFLICT')
        elif role == 'server_like' and rule['role'] in ('server_like','unknown'):
            recommendation = 'VERIFY_CANDIDATE'
            reasons.append('MODEL_SERVER_SUPPORT')
        elif role == 'client_like':
            recommendation, priority = 'REVIEW_REQUIRED', 'low'
            reasons.append('MODEL_CLIENT_REVIEW')
        else:
            recommendation = 'REVIEW_REQUIRED'
            reasons.append('MODEL_UNCERTAIN')
    else:
        recommendation = 'VERIFY_CANDIDATE' if rule['role']=='server_like' else 'REVIEW_REQUIRED'
        reasons.append('RULES_ONLY')
    if status == 'failed' and 'MODEL_FAILURE' not in reasons:
        reasons.append('MODEL_FAILURE')
    return obj | dict(schema_version=SCHEMA_VERSION, tenant_id=ctx.tenant_id, project_id=ctx.project_id,
                      dataset_id=ctx.dataset_id, network_namespace=ctx.network_namespace, test_fixture=ctx.test_fixture,
                      rule_version=RULE_VERSION, rule_role=rule['role'], model_role=role, model=model,
                      final_recommendation=recommendation, decision_source=source, model_adopted=adopted,
                      model_blocked_by_hard_rule=blocked, review_priority=priority,
                      reason_codes=list(dict.fromkeys(reasons)), explanation_zh=' '.join(REASONS[r] for r in dict.fromkeys(reasons)),
                      external_reachability='NOT_VERIFIED')
