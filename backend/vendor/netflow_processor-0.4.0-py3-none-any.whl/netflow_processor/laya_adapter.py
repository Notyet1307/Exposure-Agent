import json
import math
import os
from pathlib import Path
import subprocess
import tempfile
import time

from .contracts import FEATURE_VERSION, QUESTION_VERSION, ROLES, PipelineError, validate_document
from jsonschema import ValidationError

QUESTIONS = {'role': {'type':'choice', 'instructions':'Classify the local endpoint service role from observed traffic statistics only.', 'criteria':{
    'server_like':'Provides a service on a stable local port to multiple peers.',
    'client_like':'Initiates requests using varying local ports.',
    'mixed':'Conflicting evidence of both service and client activity.',
    'unknown':'Insufficient evidence to identify a service role.'}}}


def model_state(obj):
    f = obj['features']
    # Deliberate allowlist excludes identifiers, free text, source data and policy labels.
    keys = ('record_count','peer_count','source_count','destination_count','host_record_count',
            'host_distinct_local_ports','host_top_port_ratio','local_port_share','reverse_tuple_count',
            'start_missing_records','end_missing_records','flags_known_records',
            'source_syn_without_ack_records','destination_syn_without_ack_records',
            'source_syn_ack_records','destination_syn_ack_records')
    return {'protocol':obj['protocol'], 'local_port_known':obj['local_port'] is not None,
            **{k:round(f[k], 4) if isinstance(f[k],float) else f[k] for k in keys}}


def model_result(status, reason=None):
    return dict(status=status, role=None, probabilities=None, confidence=None, input_tokens=None,
                inference_seconds=None, error_code=reason, real_inference=False)


def validate_answer(event, expected_id, device, roles=ROLES):
    try:
        if event['event'] != 'prediction' or event['id'] != expected_id or event['device'] != device:
            raise ValueError()
        answer = event['answer']
        if not isinstance(answer, dict) or answer['model'] != 'laya-rl-agent' or not isinstance(answer['answers'],dict) or set(answer['answers']) != {'role'}:
            raise ValueError()
        a = answer['answers']['role']
        if not isinstance(a,dict) or set(a) != {'type','choice','probabilities','confidence','action'} or a['type'] != 'choice' or a['choice'] not in roles:
            raise ValueError()
        probs = a['probabilities']
        if not isinstance(probs,dict) or set(probs) != set(roles):
            raise ValueError()
        if not isinstance(a['action'],dict) or set(a['action']) != {'act_probability'} or not isinstance(answer['usage'],dict):
            raise ValueError()
        numbers = list(probs.values()) + [a['confidence'], a['action']['act_probability']]
        if any(type(n) not in (int,float) or not math.isfinite(n) or not 0 <= n <= 1 for n in numbers):
            raise ValueError()
        if abs(sum(probs.values())-1)>0.001 or probs[a['choice']] < max(probs.values()):
            raise ValueError()
        tokens, seconds = event['input_tokens_checked'], event['inference_seconds']
        if type(tokens) is not int or tokens < 1 or type(answer['usage']['input_tokens']) is not int or answer['usage']['input_tokens'] != tokens or answer['usage']['output_tokens'] != 0:
            raise ValueError()
        if type(seconds) not in (int,float) or not math.isfinite(seconds) or seconds < 0:
            raise ValueError()
        return dict(status='success', role=a['choice'], probabilities=probs, confidence=a['confidence'],
                    input_tokens=tokens, inference_seconds=seconds, error_code=None, real_inference=True)
    except (KeyError, TypeError, ValueError):
        raise PipelineError('MODEL_INVALID_OUTPUT', 3) from None


def validate_config(cfg):
    required = {'transport','python','model_path','model_id','model_revision','package_version','device','timeout_seconds'}
    if not isinstance(cfg,dict) or set(cfg) != required or any(cfg[k] is None for k in required):
        raise PipelineError('MODEL_NOT_CONFIGURED', 3)
    if cfg['transport'] != 'local-python' or cfg['device'] not in ('mps','cpu') or cfg['package_version'] != '0.3.6':
        raise PipelineError('UNSUPPORTED_MODEL_CONFIG', 3)
    if any(not isinstance(cfg[k],str) or not Path(cfg[k]).is_absolute() for k in ('python','model_path')):
        raise PipelineError('MODEL_PATH_NOT_ABSOLUTE', 3)
    if not Path(cfg['python']).is_file() or not os.access(cfg['python'], os.X_OK) or not Path(cfg['model_path']).is_dir():
        raise PipelineError('MODEL_PATH_MISSING', 3)
    if type(cfg['timeout_seconds']) not in (int,float) or not math.isfinite(cfg['timeout_seconds']) or not 0 < cfg['timeout_seconds'] <= 3600:
        raise PipelineError('INVALID_MODEL_TIMEOUT', 3)


def doctor(cfg):
    try:
        validate_config(cfg)
        code = 'import importlib.metadata,json; print(json.dumps({"laya":importlib.metadata.version("laya"),"python":__import__("sys").version.split()[0]}))'
        r = subprocess.run([cfg['python'],'-I','-B','-c',code], capture_output=True, timeout=15, check=True)
        versions = json.loads(r.stdout)
        if versions['laya'] != cfg['package_version']:
            raise PipelineError('SDK_VERSION_MISMATCH',3)
        root = Path(cfg['model_path'])
        names = ('model.safetensors','rl_agent_config.json','tokenizer/tokenizer.json','tokenizer/tokenizer_config.json','encoder/config.json','download-manifest.json')
        if any(not (root/n).is_file() for n in names):
            raise PipelineError('MODEL_FILES_MISSING',3)
        return dict(status='configured', versions=versions, real_inference_count=0,
                    notice='File and package checks only. Use analyze/evaluate for real inference.')
    except PipelineError as e:
        return dict(status='blocked', error_code=e.code, real_inference_count=0)
    except (OSError, ValueError, subprocess.SubprocessError):
        return dict(status='blocked', error_code='MODEL_INTERPRETER_FAILED', real_inference_count=0)


def classify(objects, cfg):
    return _predict_items([{'id':o['object_key'], 'state':model_state(o)} for o in objects], cfg,
                          questions=QUESTIONS, question_version=QUESTION_VERSION, feature_version=FEATURE_VERSION, roles=ROLES)


def _predict_items(items, cfg, *, questions, question_version, feature_version, roles):
    """One owned subprocess per bounded batch; loads the existing model once."""
    started = time.perf_counter()
    outcomes = {item['id']:model_result('failed','MODEL_NOT_EXECUTED') for item in items}
    summary = dict(status='failed', requested_groups=len(items), real_inference_count=0,
                   successful_groups=0, failed_groups=len(items), skipped_groups=0,
                   inference_seconds=0.0, wall_seconds=0.0, metadata=None, runtime=None,
                   error_code=None, completion_observed=False)
    try:
        validate_config(cfg)
        payload = dict(config=cfg, questions=questions, question_version=question_version, feature_version=feature_version, items=items)
        request = json.dumps(payload, allow_nan=False).encode()
        timeout = False
        with tempfile.TemporaryFile() as response:
            proc = subprocess.Popen([cfg['python'],'-I','-B',str(Path(__file__).with_name('_laya_worker.py'))],
                                    stdin=subprocess.PIPE, stdout=response, stderr=subprocess.DEVNULL)
            try:
                proc.communicate(request, timeout=cfg['timeout_seconds'])
            except subprocess.TimeoutExpired:
                timeout = True
                proc.kill()
                proc.communicate()
            except BaseException:
                proc.kill()
                proc.communicate()
                raise
            if response.tell() > 16384 + len(items)*8192:
                raise PipelineError('MODEL_RESPONSE_LIMIT',3)
            response.seek(0)
            seen, ready, complete = set(), False, False
            global_error = 'MODEL_TIMEOUT' if timeout else None
            for line in response:
                try:
                    def reject_constant(value):
                        raise ValueError()
                    event = json.loads(line, parse_constant=reject_constant)
                    kind = event['event']
                    if complete:
                        raise ValueError()
                    if kind == 'ready':
                        if ready:
                            raise ValueError()
                        validate_document(event['metadata'], 'model_metadata')
                        if any(event['metadata'][k] != cfg[k] for k in ('device','package_version','model_id','model_revision')):
                            raise ValueError()
                        if event['metadata']['question_version'] != question_version or event['metadata']['feature_template_version'] != feature_version:
                            raise ValueError()
                        ready = True
                        summary['metadata'] = event['metadata']
                    elif kind == 'prediction':
                        key = event['id']
                        if not ready or key not in outcomes or key in seen:
                            raise ValueError()
                        seen.add(key)
                        # Count actual SDK returns independently of output-schema validity.
                        summary['real_inference_count'] += 1
                        outcomes[key] = validate_answer(event, key, cfg['device'], roles)
                        summary['inference_seconds'] += outcomes[key]['inference_seconds']
                    elif kind == 'failure':
                        key = event['id']
                        if not ready or key not in outcomes or key in seen or event['code'] != 'TOKEN_BUDGET_EXCEEDED':
                            raise ValueError()
                        seen.add(key)
                        outcomes[key] = model_result('failed', event['code'])
                    elif kind == 'complete':
                        if not ready or complete or event['model_files_unchanged'] is not True:
                            raise ValueError()
                        runtime = {k:event[k] for k in ('model_files_unchanged','peak_rss_mib','mps_driver_allocated_mib')}
                        validate_document(runtime, 'model_runtime')
                        complete = True
                        summary['runtime'] = runtime
                    elif kind == 'error':
                        allowed = {'MODEL_FILES_MISSING','SDK_WOULD_MODIFY_MODEL_CONFIG','SDK_VERSION_MISMATCH','MODEL_REVISION_MISMATCH','WEIGHT_HASH_MISMATCH','DEVICE_FALLBACK_REJECTED','WORKER_EXECUTION_FAILED'}
                        global_error = event['code'] if event['code'] in allowed else 'MODEL_INVALID_OUTPUT'
                    else:
                        raise ValueError()
                except (ValueError, KeyError, TypeError, PipelineError, ValidationError):
                    global_error = 'MODEL_INVALID_OUTPUT'
            summary['completion_observed'] = complete
            if len(seen) != len(items) or not complete or proc.returncode != 0:
                global_error = global_error or 'MODEL_INCOMPLETE_BATCH'
            if global_error:
                raise PipelineError(global_error,3)
            if any(v['status'] == 'failed' for v in outcomes.values()):
                summary['error_code'] = 'MODEL_GROUP_FAILURE'
            else:
                summary['status'] = 'success'
    except PipelineError as e:
        summary['error_code'] = e.code
        # A broken batch is not published as an apparently successful model result.
        outcomes = {key:model_result('failed', e.code) for key in outcomes}
    except (OSError, subprocess.SubprocessError):
        summary['error_code'] = 'MODEL_LAUNCH_FAILED'
        outcomes = {key:model_result('failed', 'MODEL_LAUNCH_FAILED') for key in outcomes}
    summary['successful_groups'] = sum(v['status']=='success' for v in outcomes.values())
    summary['failed_groups'] = len(items)-summary['successful_groups']
    summary['wall_seconds'] = time.perf_counter()-started
    return outcomes, summary


def check_notes(checks, cfg):
    """Experimental hints only: all six option orders must support the claim.

    No structured answer, task identity, source address or reviewer metadata is
    added to the note/claim input. A hint never changes material/task status.
    """
    from itertools import permutations
    labels = ('entailment','contradiction','neutral')
    options = dict(zip(labels, ('备注内容支持该陈述。','备注内容与该陈述矛盾。','备注信息不足，无法判断该陈述。')))
    if len(checks) > 32 or len({c['id'] for c in checks}) != len(checks):
        raise PipelineError('NOTE_CHECK_LIMIT', 4)
    items=[]
    for check in checks:
        for index, order in enumerate(permutations(labels)):
            q={'role':{'type':'choice','instructions':'备注与陈述是什么关系？仅判断文字内容。',
                       'criteria':{label:options[label] for label in order}}}
            items.append({'id':check['id']+':'+str(index),'state':f"备注：{check['note']}\n陈述：{check['claim']}", 'questions':q})
    if not items:
        return {}, dict(status='skipped',requested_groups=0,real_inference_count=0,successful_groups=0,failed_groups=0,
            skipped_groups=0,inference_seconds=0.,wall_seconds=0.,metadata=None,runtime=None,error_code='NO_NOTE_CHECKS',completion_observed=False)
    outcomes, summary=_predict_items(items,cfg,questions=items[0]['questions'],question_version='netflow-note-question-v1',
                                    feature_version='netflow-note-pair-v1',roles=labels)
    hints={}
    for check in checks:
        values=[outcomes[check['id']+':'+str(index)] for index in range(6)]
        success=summary['status']=='success' and all(v['status']=='success' for v in values)
        roles_found={v['role'] for v in values} if success else set()
        hints[check['id']]=dict(status='success' if success else 'failed',
            hint='TEXT_SUPPORT_SUGGESTED' if roles_found=={'entailment'} else 'UNRESOLVED',
            consistent=len(roles_found)==1 if success else None, predictions=values,
            error_code=None if success else summary['error_code'], experimental=True,changes_material_status=False)
    return hints,summary
