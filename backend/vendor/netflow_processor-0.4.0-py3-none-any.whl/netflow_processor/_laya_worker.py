"""Executed by the existing Laya interpreter, without importing this package.

Input and output are a private bounded protocol. Role calls use numeric summaries;
explicit experimental note calls use only caller-selected note/claim text.
The parent never adds endpoints, tenant metadata or raw flow records to either.
"""
import contextlib
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import resource
import sys
import time

os.environ.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_HUB_DISABLE_TELEMETRY='1', TOKENIZERS_PARALLELISM='false')


def emit(value):
    sys.__stdout__.write(json.dumps(value, allow_nan=False, separators=(',', ':')) + '\n')
    sys.__stdout__.flush()


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for b in iter(lambda: stream.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()


def token_check(agent, state, questions):
    from laya.common import render_options, serialize_state, build_sequence
    q = agent._to_internal(questions['role'])
    tok = agent.tok
    encode = lambda x: tok(x.replace(tok.mask_token, ' '), add_special_tokens=False)['input_ids']
    head = encode(q['t'] + ' question: ' + q['ins'])
    opts = [encode(' ' + value) for value in render_options(q)]
    if any(len(o) > 48 for o in opts):
        raise ValueError('TOKEN_BUDGET')
    option_size = sum(len(o)+1 for o in opts)
    if agent.cfg['head_max_len'] - option_size < max(16, len(head)):
        raise ValueError('TOKEN_BUDGET')
    length = 4 + len(head) + option_size + len(encode(serialize_state(state)))
    seq, markers = build_sequence(tok, state, q, agent.cfg['max_len'], agent.cfg['head_max_len'])
    if length > agent.cfg['max_len'] or len(seq) != length or len(markers) != len(opts):
        raise ValueError('TOKEN_BUDGET')
    return length


def main():
    payload = json.load(sys.stdin)
    cfg = payload['config']
    root = Path(cfg['model_path'])
    required = ('rl_agent_config.json','model.safetensors','tokenizer/tokenizer.json','tokenizer/tokenizer_config.json','encoder/config.json','download-manifest.json')
    if not root.is_absolute() or any(not (root/name).is_file() for name in required):
        raise ValueError('MODEL_FILES_MISSING')
    tcfg = json.loads((root/'tokenizer/tokenizer_config.json').read_text())
    if tcfg.get('tokenizer_class') in (None, 'TokenizersBackend') or isinstance(tcfg.get('extra_special_tokens'), list):
        raise ValueError('SDK_WOULD_MODIFY_MODEL_CONFIG')
    version = importlib.metadata.version('laya')
    if version != cfg['package_version'] or version != '0.3.6':
        raise ValueError('SDK_VERSION_MISMATCH')
    provenance = json.loads((root/'download-manifest.json').read_text())
    if provenance['revision'] != cfg['model_revision'] or cfg['model_id'] != provenance['repo']+'/multilingual':
        raise ValueError('MODEL_REVISION_MISMATCH')
    before = {name: sha(root/name) for name in required}
    expected_weight = next(f['lfs']['oid'] for f in provenance['files'] if f['path']=='multilingual/model.safetensors')
    if before['model.safetensors'] != expected_weight:
        raise ValueError('WEIGHT_HASH_MISMATCH')
    started = time.perf_counter()
    import torch
    import laya
    import laya.agent
    import laya.common
    torch.set_num_threads(4)
    agent = laya.load(str(root), device=cfg['device'])

    def sync():
        if agent.device.type == 'mps':
            torch.mps.synchronize()

    sync()
    if str(agent.device) != cfg['device']:
        raise ValueError('DEVICE_FALLBACK_REJECTED')
    metadata = dict(package_version=version, model_id=cfg['model_id'], model_revision=provenance['revision'],
                    weight_sha256=before['model.safetensors'], model_files_sha256=before,
                    sdk_agent_sha256=sha(Path(laya.agent.__file__)), sdk_common_sha256=sha(Path(laya.common.__file__)),
                    device=str(agent.device), load_seconds=time.perf_counter()-started,
                    max_tokens=agent.cfg['max_len'], head_max_tokens=agent.cfg['head_max_len'],
                    question_version=payload['question_version'], feature_template_version=payload['feature_version'])
    emit({'event':'ready', 'metadata':metadata})
    for item in payload['items']:
        questions = item.get('questions', payload['questions'])
        try:
            length = token_check(agent, item['state'], questions)
        except ValueError:
            emit({'event':'failure', 'id':item['id'], 'code':'TOKEN_BUDGET_EXCEEDED'})
            continue
        sync()
        started = time.perf_counter()
        answer = agent.predict(item['state'], questions)
        sync()
        emit({'event':'prediction', 'id':item['id'], 'answer':answer, 'input_tokens_checked':length,
              'inference_seconds':time.perf_counter()-started, 'device':str(agent.device)})
    unchanged = before == {name: sha(root/name) for name in required}
    emit({'event':'complete', 'model_files_unchanged':unchanged,
          'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024**2 if sys.platform=='darwin' else 1024),
          'mps_driver_allocated_mib':torch.mps.driver_allocated_memory()/1024**2 if agent.device.type=='mps' else None})


if __name__ == '__main__':
    try:
        with open(os.devnull, 'w') as sink, contextlib.redirect_stdout(sink), contextlib.redirect_stderr(sink):
            main()
    except Exception as exc:
        codes = {'MODEL_FILES_MISSING','SDK_WOULD_MODIFY_MODEL_CONFIG','SDK_VERSION_MISMATCH','MODEL_REVISION_MISMATCH','WEIGHT_HASH_MISMATCH','DEVICE_FALLBACK_REJECTED'}
        code = str(exc) if isinstance(exc, ValueError) and str(exc) in codes else 'WORKER_EXECUTION_FAILED'
        emit({'event':'error', 'code':code})
        sys.exit(3)
