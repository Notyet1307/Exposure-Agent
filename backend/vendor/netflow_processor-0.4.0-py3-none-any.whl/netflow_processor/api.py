"""One business entry point shared by CLI, evaluation and Exposure example."""
from collections import Counter
from dataclasses import asdict
import os
from pathlib import Path
import resource
import shutil
import sqlite3
import sys
import tempfile
import time
import uuid

from .contracts import VERSION, SCHEMA_VERSION, RULE_VERSION, FEATURE_VERSION, QUESTION_VERSION, PipelineError, ProcessingResult, digest, validate_document
from .readers import rows, hash_file
from .features import Aggregator
from .decision import baseline, fuse
from . import laya_adapter
from .outputs import Writer, write_json


def process_file(input_path: Path, *, context, config, output_dir: Path) -> ProcessingResult:
    config.validate()
    networks = context.validate()
    input_path, output_dir = Path(input_path), Path(output_dir)
    # Reserve a new directory exclusively. Manifest is the last atomic commit marker.
    # Interrupted runs remain uncommitted; retries always use a new directory.
    output_dir.mkdir(parents=True, exist_ok=False)
    output_dir.chmod(0o700)
    stage = Path(tempfile.mkdtemp(prefix='.staging-', dir=output_dir))
    started = time.perf_counter()
    counts = dict(raw_records=0, valid_records=0, invalid_records=0, duplicate_records=0,
                  mapped_addresses_normalized=0, records_without_managed_endpoint=0,
                  self_loop_records=0, endpoint_count=0, service_hypotheses=0,
                  observations=0, candidates=0, review=0, excluded=0)
    timings = dict(fingerprint_seconds=0.0, read_normalize_seconds=0.0, aggregate_seconds=0.0,
                   feature_decision_output_seconds=0.0, model_wall_seconds=0.0, model_inference_seconds=0.0, total_seconds=0.0)
    metadata = dict(encoding=None, ignored_column_count=0)
    manifest = dict(schema_version=SCHEMA_VERSION, component_version=VERSION, run_id=str(uuid.uuid4()),
                    tenant_id=context.tenant_id, project_id=context.project_id, dataset_id=context.dataset_id,
                    network_namespace=context.network_namespace, test_fixture=context.test_fixture,
                    input_profile=config.input_profile, input_sha256=None, input_bytes=None,
                    config_version='netflow-config-v1', config_sha256=digest(asdict(config)), context_sha256=digest(asdict(context)),
                    rules_version=RULE_VERSION, feature_template_version=FEATURE_VERSION, question_template_version=QUESTION_VERSION,
                    policy=config.policy, limits=config.bounds, analysis_context=asdict(context),
                    mode=config.mode, status='success', pipeline_complete=False, exit_code=0,
                    input_state='failed', counts=counts, data_quality={}, coverage_limitations=[],
                    model=dict(status='skipped', requested_groups=0, real_inference_count=0, successful_groups=0,
                               failed_groups=0, skipped_groups=0, inference_seconds=0.0, wall_seconds=0.0,
                               metadata=None, runtime=None, error_code=None, completion_observed=False),
                    artifacts=[], errors=[], timings=timings, peak_rss_mib=None)
    source_only = context.endpoint_selection == 'declared_source'
    writer = Writer(stage, config.bounds['max_output_bytes'], include_peers=source_only)
    warnings = Counter()
    agg = None
    input_complete = False
    try:
        before = time.perf_counter()
        fingerprint, size = hash_file(input_path, config.bounds['max_input_bytes'])
        stat = input_path.stat()
        manifest.update(input_sha256=fingerprint, input_bytes=size)
        timings['fingerprint_seconds'] += time.perf_counter()-before
        agg = Aggregator(context, config, networks)
        with sqlite3.connect(stage/'duplicates.sqlite') as duplicates:
            duplicates.execute('PRAGMA journal_mode=OFF')
            duplicates.execute('PRAGMA cache_size=-2048')
            duplicates.execute('CREATE TABLE seen (digest TEXT PRIMARY KEY) WITHOUT ROWID')
            iterator = iter(rows(input_path, context, config, metadata))
            while True:
                before = time.perf_counter()
                item = next(iterator, None)
                timings['read_normalize_seconds'] += time.perf_counter()-before
                if item is None:
                    input_complete = True
                    break
                index, row, codes, error = item
                counts['raw_records'] += 1
                if error:
                    counts['invalid_records'] += 1
                    writer.put('invalid-records.jsonl', {'schema_version':SCHEMA_VERSION, 'source_ref':'row:'+str(index), 'error_codes':[error]}, 'invalid_record')
                    continue
                warnings.update(codes)
                for field in ('start_time','end_time','in_bytes','in_packets'):
                    if getattr(row,field) is None:
                        warnings['MISSING_'+field.upper()] += 1
                if row.protocol == 6 and row.tcp_flags is None:
                    warnings['MISSING_TCP_FLAGS'] += 1
                if row.protocol in (6,17) and (row.src_port is None or row.dst_port is None):
                    warnings['MISSING_TRANSPORT_PORT'] += 1
                counts['valid_records'] += 1
                counts['mapped_addresses_normalized'] += row.mapped_count
                before = time.perf_counter()
                cur = duplicates.execute('INSERT OR IGNORE INTO seen VALUES (?)', (digest(row.duplicate_payload()),))
                counts['duplicate_records'] += cur.rowcount == 0
                agg.add(row)
                timings['aggregate_seconds'] += time.perf_counter()-before
        before = time.perf_counter()
        after = input_path.stat()
        check, _ = hash_file(input_path, config.bounds['max_input_bytes'])
        if check != fingerprint or (stat.st_ino,stat.st_mtime_ns,stat.st_size) != (after.st_ino,after.st_mtime_ns,after.st_size):
            raise PipelineError('INPUT_CHANGED_DURING_PROCESSING')
        timings['fingerprint_seconds'] += time.perf_counter()-before
        if counts['invalid_records'] and config.invalid_policy == 'fail':
            raise PipelineError('DATA_QUALITY_POLICY_FAILED')
        if len(agg.groups) + len(agg.peer_groups) > config.bounds['max_output_items']:
            raise PipelineError('OUTPUT_ITEMS_LIMIT',4)
        # Only model-bound groups are materialized, bounded independently of output count.
        eligible = []
        if config.mode == 'assisted' and context.scope_confirmation != 'conflict':
            for obj in agg.observations():
                rule = baseline(obj, context, config)
                if not rule['exclude'] and not rule['review']:
                    if len(eligible) >= config.bounds['max_model_groups']:
                        raise PipelineError('MODEL_GROUP_LIMIT',4)
                    eligible.append(obj)
        outcomes = {}
        if eligible:
            outcomes, summary = laya_adapter.classify(eligible, config.laya)
            manifest['model'] = summary
            timings['model_wall_seconds'] = summary['wall_seconds']
            timings['model_inference_seconds'] = summary['inference_seconds']
            if summary['status'] == 'failed':
                manifest['errors'].append({'code':summary['error_code'], 'stage':'model'})
                manifest['status'] = 'degraded' if config.allow_rule_fallback else 'failed'
                manifest['exit_code'] = 5 if config.allow_rule_fallback else 3
        else:
            manifest['model']['error_code'] = 'RULES_MODE' if config.mode == 'rules' else 'EMPTY_OR_HARD_GATED'
        manifest['model']['skipped_groups'] = len(agg.groups)-len(eligible)
        before = time.perf_counter()
        for obj in agg.observations():
            rule = baseline(obj, context, config)
            skip_reason = 'RULES_MODE' if config.mode=='rules' else 'HARD_EXCLUDED' if rule['exclude'] else 'HARD_REVIEW_GATE'
            model = outcomes.get(obj['object_key'], laya_adapter.model_result('skipped', skip_reason))
            obs = fuse(obj, rule, model, context, config)
            verified = manifest['model']['metadata']
            obs['model_version'] = ({k:verified[k] for k in ('model_id','model_revision','package_version','question_version')}
                                    if verified and model['status']=='success' else None)
            rec = obs['final_recommendation']
            batch = [('observations.jsonl', obs, 'observation')]
            if rec == 'VERIFY_CANDIDATE':
                batch.append(('candidates.jsonl', obs, 'candidate'))
            elif rec == 'REVIEW_REQUIRED':
                batch.append(('review.jsonl', obs, 'review'))
            writer.put_many(batch)
            counts['observations'] += 1
            counts[{'VERIFY_CANDIDATE':'candidates','REVIEW_REQUIRED':'review','EXCLUDE_BY_RULE':'excluded'}[rec]] += 1
        for peer in agg.peers():
            writer.put('peers.jsonl', peer, 'peer')
        timings['feature_decision_output_seconds'] = time.perf_counter()-before
        if context.scope_confirmation == 'conflict':
            raise PipelineError('SCOPE_CONFLICT')
        manifest['pipeline_complete'] = manifest['status'] != 'failed'
    except PipelineError as e:
        manifest.update(status='failed', pipeline_complete=False, exit_code=e.exit_code)
        manifest['errors'].append({'code':e.code, 'stage':'pipeline'})
    except (OSError, sqlite3.Error):
        manifest.update(status='failed', pipeline_complete=False, exit_code=2)
        manifest['errors'].append({'code':'LOCAL_IO_FAILURE', 'stage':'pipeline'})
    finally:
        writer.close()
    if agg:
        counts.update(records_without_managed_endpoint=agg.without_managed, self_loop_records=agg.self_loops,
                      endpoint_count=len({ip for ip, proto in agg.hosts}), service_hypotheses=len(agg.groups))
        if source_only:
            counts.update(peer_addresses=len({g.ip for g in agg.peer_groups.values()}), peer_hypotheses=len(agg.peer_groups),
                          address_side_crossover_count=len(agg.address_crossover()))
    if input_complete:
        manifest['input_state'] = ('empty' if not counts['raw_records'] else 'all_invalid' if not counts['valid_records'] else
                                   'data_with_candidates' if counts['candidates'] else 'data_without_candidates')
    if metadata['ignored_column_count']:
        warnings['IGNORED_COLUMNS'] = metadata['ignored_column_count']
    if counts['duplicate_records']:
        warnings['DUPLICATES_RETAINED'] = counts['duplicate_records']
    if counts['invalid_records']:
        warnings['QUARANTINED_RECORDS'] = counts['invalid_records']
    limitations = ['INPUT_RECORDS_NOT_SESSIONS', 'REACHABILITY_NOT_VERIFIED', 'OBSERVATION_COVERAGE_NOT_COMPLETE',
                  'REVERSE_TUPLES_DO_NOT_PROVE_HANDSHAKE', 'COUNTERS_NOT_RESCALED']
    if context.sampling['mode'] == 'unknown':
        limitations.append('SAMPLING_UNKNOWN')
        warnings['SAMPLING_UNKNOWN'] = 1
    if config.input_profile == 'exposure':
        limitations.append('ORIGINAL_MAPPED_FORM_UNRECOVERABLE')
    if context.test_fixture:
        limitations.append('SYNTHETIC_TEST_ONLY')
    if source_only:
        limitations += ['SOURCE_POSITION_DECLARATION_NOT_OWNERSHIP_OR_AUTHORIZATION', 'SOURCE_COLUMN_NOT_CONNECTION_INITIATOR',
                        'REVERSE_MATCHING_NOT_EVALUATED', 'EXTERNAL_PEER_BY_CUSTOMER_DECLARATION']
    if not input_complete:
        limitations.append('INPUT_PROCESSING_INCOMPLETE')
    manifest['coverage_limitations'] = limitations
    manifest['data_quality'] = dict(warnings=dict(warnings), input_processing_complete=input_complete, **metadata,
                                    duplicate_definition='normalized_known_fields_excluding_source_ref_preserved_in_counts',
                                    endpoint_counting=('source_column_once_per_record_destination_separate' if source_only else 'both_managed_ends_each_count_once_self_loop_endpoint_once'))
    if warnings and manifest['status'] == 'success':
        manifest['status'] = 'success_with_warnings'
    manifest['artifacts'] = writer.artifacts()
    timings['total_seconds'] = time.perf_counter()-started
    manifest['peak_rss_mib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024)
    validate_document(manifest, 'manifest')
    write_json(stage/'manifest.json', manifest)
    for artifact in manifest['artifacts']:
        os.replace(stage/artifact['path'], output_dir/artifact['path'])
    os.replace(stage/'manifest.json', output_dir/'manifest.json')
    shutil.rmtree(stage)
    return ProcessingResult(output_dir, manifest)
