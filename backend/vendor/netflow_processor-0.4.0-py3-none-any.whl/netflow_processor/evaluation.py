from dataclasses import replace
from pathlib import Path
import time

from .api import process_file
from .contracts import PipelineError, ProcessingContext, read_json
from .outputs import write_json


def evaluate(cases_path, config, output_dir):
    cases_path, output_dir = Path(cases_path), Path(output_dir)
    spec = read_json(cases_path)
    if spec.get('contract') != 'netflow-evaluation-v1' or not isinstance(spec.get('datasets'), list) or not spec['datasets'] or len(spec['datasets']) > 10:
        raise PipelineError('INVALID_EVALUATION_CASES')
    output_dir.mkdir(parents=True, exist_ok=False)
    report = dict(contract='netflow-evaluation-result-v1', test_fixture=True, status='success',
                  label_source=spec['label_source'], evaluation_unit='labelled_service_hypothesis; endpoint labels may match multiple ports',
                  role_basis='assisted uses model on inferred groups and rules on explicitly skipped groups; failed groups remain not_run',
                  limits='Synthetic engineering cases only. No representative business accuracy or public reachability estimate.', datasets=[])
    for index, dataset in enumerate(spec['datasets']):
        ctx = ProcessingContext.from_dict(read_json(cases_path.parent/dataset['context']))
        if not ctx.test_fixture:
            raise PipelineError('EVALUATION_REQUIRES_SYNTHETIC_CONTEXT')
        if dataset['split'] not in ('development','holdout') or not dataset['labels']:
            raise PipelineError('INVALID_EVALUATION_LABELS')
        for mode in ('rules','assisted'):
            started = time.perf_counter()
            r = process_file(cases_path.parent/dataset['input'], context=ctx,
                             config=replace(config, mode=mode, input_profile=dataset['profile'], allow_rule_fallback=False),
                             output_dir=output_dir/(str(index)+'-'+mode))
            if r.exit_code:
                report['status'] = 'failed'
            observations = list(r.observations())
            confusion, mistakes, matched, correct, unknown = {}, [], 0, 0, 0
            inferred, model_correct, skipped = 0, 0, 0
            prediction_counts = dict(tp=0,fp=0,tn=0,fn=0)
            for label in dataset['labels']:
                selected = [o for o in observations if o['ip'] == label['endpoint'] and ('port' not in label or o['local_port']==label['port'])]
                if not selected:
                    raise PipelineError('EVALUATION_LABEL_NOT_MATCHED')
                for o in selected:
                    actual = o['model_role'] if mode=='assisted' and o['model']['status']=='success' else o['rule_role']
                    if mode=='assisted' and o['model']['status']=='failed':
                        actual = 'not_run'
                    truth = label['role']
                    if mode=='assisted':
                        inferred += o['model']['status']=='success'
                        model_correct += o['model']['status']=='success' and o['model_role']==truth
                        skipped += o['model']['status']=='skipped'
                    predicted = o['final_recommendation']=='VERIFY_CANDIDATE'
                    expected = label['candidate']
                    prediction_counts['tp' if expected and predicted else 'fn' if expected else 'fp' if predicted else 'tn'] += 1
                    matched += 1
                    correct += actual == truth
                    unknown += actual == 'unknown'
                    key = truth+'->'+actual
                    confusion[key] = confusion.get(key,0)+1
                    if actual != truth or predicted != expected:
                        mistakes.append(dict(case=label['id'], object_key=o['object_key'], expected_role=truth,
                                             predicted_role=actual, expected_candidate=expected, recommendation=o['final_recommendation']))
            report['datasets'].append(dict(dataset=dataset['id'], split=dataset['split'], mode=mode,
                labelled_hypotheses=matched, correct_roles=correct, role_accuracy=correct/matched,
                unknown_ratio=unknown/matched, confusion=confusion, candidate_classification=prediction_counts,
                model_labelled_hypotheses=inferred, model_correct_roles=model_correct,
                model_role_accuracy=model_correct/inferred if inferred else None, skipped_labelled_hypotheses=skipped,
                candidates=r.manifest['counts']['candidates'], reviews=r.manifest['counts']['review'],
                model=r.manifest['model'], timings=r.manifest['timings'], peak_rss_mib=r.manifest['peak_rss_mib'],
                wall_seconds=time.perf_counter()-started, mistakes=mistakes, result_directory=str(index)+'-'+mode))
    write_json(output_dir/'evaluation.json', report)
    return report
