from dataclasses import asdict, dataclass, field, fields
import hashlib
from importlib.resources import files
import ipaddress
import json
import math
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

VERSION = '0.4.0'
SCHEMA_VERSION = 'netflow-candidates-v1'
RULE_VERSION = 'netflow-rules-v2'
FEATURE_VERSION = 'netflow-features-v2'
QUESTION_VERSION = 'netflow-role-question-v1'
ROLES = ('server_like', 'client_like', 'mixed', 'unknown')


class PipelineError(Exception):
    def __init__(self, code, exit_code=2):
        self.code, self.exit_code = code, exit_code
        super().__init__(code)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False, separators=(',', ':')).encode()).hexdigest()


def read_json(path):
    def reject(_):
        raise ValueError('nonfinite JSON')
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'), parse_constant=reject)
    except (OSError, ValueError):
        raise PipelineError('INVALID_JSON_CONFIG') from None


def construct(cls, value):
    if not isinstance(value, dict) or set(value) - {f.name for f in fields(cls)}:
        raise PipelineError('UNKNOWN_CONFIG_FIELDS')
    try:
        return cls(**value)
    except TypeError:
        raise PipelineError('MISSING_CONFIG_FIELDS') from None


def enum(value, allowed, code):
    if value not in allowed:
        raise PipelineError(code)


@dataclass(frozen=True)
class ProcessingContext:
    tenant_id: str
    project_id: str
    dataset_id: str
    network_namespace: str
    scope_confirmation: str
    managed_cidrs: list
    observation_point: dict
    sampling: dict
    input_timezone: str
    test_fixture: bool = False
    context_contract: str = 'netflow-context-v1'
    fixture_notice: str = ''
    endpoint_selection: str = 'by_cidr'
    scope_evidence: str = ''

    @classmethod
    def from_dict(cls, data):
        return construct(cls, data)

    def validate(self):
        for v in (self.tenant_id, self.project_id, self.dataset_id, self.network_namespace):
            if not isinstance(v, str) or not v.strip() or len(v) > 128 or any(ord(c) < 32 for c in v):
                raise PipelineError('INVALID_CONTEXT_ID')
        if self.context_contract != 'netflow-context-v1' or type(self.test_fixture) is not bool:
            raise PipelineError('INVALID_CONTEXT')
        if not isinstance(self.fixture_notice,str) or len(self.fixture_notice)>1024:
            raise PipelineError('INVALID_CONTEXT')
        enum(self.scope_confirmation, ('confirmed', 'unknown', 'conflict'), 'INVALID_SCOPE')
        if not isinstance(self.managed_cidrs, list) or len(self.managed_cidrs) > 256 or any(not isinstance(n,str) or '/' not in n for n in self.managed_cidrs):
            raise PipelineError('INVALID_CIDRS')
        try:
            networks = [ipaddress.ip_network(n, strict=True) for n in self.managed_cidrs]
        except (ValueError, TypeError):
            raise PipelineError('INVALID_CIDRS') from None
        enum(self.endpoint_selection, ('by_cidr', 'declared_source'), 'INVALID_ENDPOINT_SELECTION')
        if not isinstance(self.scope_evidence, str) or len(self.scope_evidence) > 2048:
            raise PipelineError('INVALID_SCOPE_EVIDENCE')
        if self.endpoint_selection == 'declared_source':
            if self.scope_confirmation != 'confirmed' or networks or not self.scope_evidence.strip():
                raise PipelineError('SOURCE_DECLARATION_REQUIRES_CONFIRMED_EVIDENCE_WITHOUT_CIDRS')
        elif self.scope_confirmation == 'confirmed' and not networks:
            raise PipelineError('CONFIRMED_SCOPE_EMPTY')
        if not isinstance(self.observation_point, dict) or set(self.observation_point) != {'id', 'view', 'nat_context'}:
            raise PipelineError('INVALID_OBSERVATION_POINT')
        if not isinstance(self.observation_point['id'], str) or not self.observation_point['id'] or len(self.observation_point['id']) > 128:
            raise PipelineError('INVALID_OBSERVATION_POINT')
        enum(self.observation_point['view'], ('PUBLIC_EDGE', 'INTERNAL', 'UNKNOWN'), 'INVALID_VIEW')
        enum(self.observation_point['nat_context'], ('none', 'mapped', 'unknown', 'explicit_no_nat_in_fixture'), 'INVALID_NAT')
        if self.observation_point['nat_context'] == 'explicit_no_nat_in_fixture' and not self.test_fixture:
            raise PipelineError('FIXTURE_NAT_IN_PRODUCTION')
        if not isinstance(self.sampling, dict) or set(self.sampling) != {'mode', 'rate'}:
            raise PipelineError('INVALID_SAMPLING')
        enum(self.sampling['mode'], ('unknown', 'unsampled', 'sampled'), 'INVALID_SAMPLING')
        rate = self.sampling['rate']
        if self.sampling['mode'] == 'unknown' and rate is not None:
            raise PipelineError('INVALID_SAMPLING')
        if self.sampling['mode'] != 'unknown' and (type(rate) not in (int, float) or not math.isfinite(rate) or not 0 < rate <= 1):
            raise PipelineError('INVALID_SAMPLING')
        if self.sampling['mode'] == 'unsampled' and rate != 1:
            raise PipelineError('INVALID_SAMPLING')
        if not isinstance(self.input_timezone, str):
            raise PipelineError('INVALID_TIMEZONE')
        if self.input_timezone != '+08:00':
            try:
                ZoneInfo(self.input_timezone)
            except (ZoneInfoNotFoundError, ValueError):
                raise PipelineError('INVALID_TIMEZONE') from None
        return networks


DEFAULT_LIMITS = dict(max_records=1_000_000, max_input_bytes=536_870_912, max_aggregate_groups=100_000,
                      max_peer_entries=500_000, max_tuple_entries=500_000, max_evidence_refs_per_item=20,
                      max_model_groups=1000, max_output_items=100_000, max_output_bytes=268_435_456,
                      max_field_chars=4096)
DEFAULT_RULES = dict(min_service_records=4, min_service_peers=2, stable_port_ratio=0.6,
                     min_client_ports=3, client_top_port_ratio=0.5)


@dataclass(frozen=True)
class ProcessorConfig:
    input_profile: str = 'raw'
    mode: str = 'rules'
    allow_rule_fallback: bool = False
    invalid_policy: str = 'fail'
    encoding: str = 'utf-8-sig'
    delimiter: str = ','
    field_mapping: dict = field(default_factory=dict)
    limits: dict = field(default_factory=dict)
    rules: dict = field(default_factory=dict)
    laya: dict | None = None

    @classmethod
    def from_dict(cls, data):
        return construct(cls, data)

    def validate(self):
        try:
            json.dumps(asdict(self), allow_nan=False)
        except (ValueError,TypeError):
            raise PipelineError('INVALID_CONFIG_VALUE') from None
        enum(self.input_profile, ('raw', 'exposure', 'exposure-raw-v1'), 'UNKNOWN_INPUT_PROFILE')
        enum(self.mode, ('rules', 'assisted'), 'INVALID_MODE')
        enum(self.invalid_policy, ('fail', 'quarantine'), 'INVALID_POLICY')
        enum(self.encoding, ('utf-8-sig', 'gb18030', 'auto'), 'INVALID_ENCODING')
        enum(self.delimiter, (',', '\t', ';', '|'), 'INVALID_DELIMITER')
        if type(self.allow_rule_fallback) is not bool:
            raise PipelineError('INVALID_FALLBACK')
        for values, defaults in ((self.limits, DEFAULT_LIMITS), (self.rules, DEFAULT_RULES)):
            if not isinstance(values, dict) or set(values) - set(defaults):
                raise PipelineError('UNKNOWN_POLICY_FIELDS')
            for k, v in values.items():
                if type(v) not in (float, int) or not math.isfinite(v) or v <= 0:
                    raise PipelineError('INVALID_POLICY_VALUE')
                if isinstance(defaults[k], int) and type(v) is not int:
                    raise PipelineError('INVALID_POLICY_VALUE')
                if k.endswith('ratio') and v > 1:
                    raise PipelineError('INVALID_POLICY_VALUE')
        if not isinstance(self.field_mapping, dict) or len(self.field_mapping) > 11 or any(not isinstance(k,str) or not isinstance(v,str) or not v or len(v)>128 for k,v in self.field_mapping.items()):
            raise PipelineError('INVALID_FIELD_MAPPING')
        if self.input_profile == 'exposure' and self.field_mapping:
            raise PipelineError('CANONICAL_MAPPING_FORBIDDEN')
        if self.laya is not None and not isinstance(self.laya, dict):
            raise PipelineError('INVALID_LAYA_CONFIG')

    @property
    def bounds(self):
        return DEFAULT_LIMITS | self.limits

    @property
    def policy(self):
        return DEFAULT_RULES | self.rules


@dataclass
class ProcessingResult:
    output_dir: Path
    manifest: dict

    @property
    def exit_code(self):
        return self.manifest['exit_code']

    def _iter(self, name):
        with (self.output_dir / name).open(encoding='utf-8') as stream:
            for line in stream:
                yield json.loads(line)

    def candidates(self):
        return self._iter('candidates.jsonl')

    def reviews(self):
        return self._iter('review.jsonl')

    def observations(self):
        return self._iter('observations.jsonl')

    def peers(self):
        return self._iter('peers.jsonl') if (self.output_dir / 'peers.jsonl').exists() else iter(())


_VALIDATORS = {}


def validate_document(document, kind):
    from jsonschema import Draft202012Validator, FormatChecker
    if kind not in _VALIDATORS:
        schema = json.loads(files('netflow_processor').joinpath('schemas/netflow-candidates-v1.json').read_text())
        schema = schema | {'$ref': '#/$defs/' + kind}
        _VALIDATORS[kind] = Draft202012Validator(schema, format_checker=FormatChecker())
    _VALIDATORS[kind].validate(document)
